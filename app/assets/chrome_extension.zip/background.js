// src/shared/cat-catch.ts
var CAT_CATCH_HLS_TYPES = /* @__PURE__ */ new Set([
  "application/vnd.apple.mpegurl",
  "application/x-mpegurl",
  "application/mpegurl",
  "application/octet-stream-m3u8"
]);
var CAT_CATCH_MPD_TYPES = /* @__PURE__ */ new Set(["application/dash+xml"]);
var CAT_CATCH_VIDEO_EXTENSIONS = /* @__PURE__ */ new Set([
  "3gp",
  "asf",
  "avi",
  "divx",
  "f4v",
  "flv",
  "hlv",
  "m4s",
  "mkv",
  "mov",
  "mp4",
  "mpeg",
  "mpeg4",
  "movie",
  "ogv",
  "ts",
  "vid",
  "webm",
  "wmv"
]);
var CAT_CATCH_AUDIO_EXTENSIONS = /* @__PURE__ */ new Set([
  "aac",
  "acc",
  "flac",
  "m4s",
  "m4a",
  "mp3",
  "ogg",
  "opus",
  "wav",
  "weba",
  "wma"
]);
var CAT_CATCH_MEDIA_EXTENSIONS = /* @__PURE__ */ new Set([
  ...CAT_CATCH_VIDEO_EXTENSIONS,
  ...CAT_CATCH_AUDIO_EXTENSIONS,
  "m3u",
  "m3u8",
  "mpd"
]);
function isCatCatchM3u8(extension, mime = "") {
  const type = String(mime || "").toLowerCase();
  return extension === "m3u8" || extension === "m3u" || CAT_CATCH_HLS_TYPES.has(type) || type.endsWith("/vnd.apple.mpegurl") || type.endsWith("/x-mpegurl") || type.endsWith("/mpegurl") || type.endsWith("/octet-stream-m3u8");
}
function isCatCatchMpd(extension, mime = "") {
  return extension === "mpd" || CAT_CATCH_MPD_TYPES.has(String(mime || "").toLowerCase());
}
function isCatCatchMedia(extension, mime = "") {
  const type = mime.toLowerCase();
  return CAT_CATCH_MEDIA_EXTENSIONS.has(extension) || type.startsWith("video/") || type.startsWith("audio/") || isCatCatchM3u8(extension, type) || isCatCatchMpd(extension, type);
}
var CAT_CATCH_SCRIPT_FEATURES = {
  recorder: { script: "recorder.js", i18n: true, allFrames: true, world: "MAIN", reloadRequired: false },
  webrtc: { script: "webrtc.js", i18n: true, allFrames: true, world: "MAIN", reloadRequired: true },
  recorder2: { script: "recorder2.js", i18n: true, allFrames: false, world: "ISOLATED", reloadRequired: false },
  search: { script: "search.js", i18n: false, allFrames: true, world: "MAIN", reloadRequired: true },
  catch: { script: "catch.js", i18n: true, allFrames: true, world: "MAIN", reloadRequired: true }
};
var MOBILE_USER_AGENT = "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.3 Mobile/15E148 Safari/604.1";

// src/shared/constants.ts
var DEFAULT_SERVER_URL = "ws://127.0.0.1:14370";
var EXTENSION_VERSION = chrome.runtime.getManifest().version;
var ADVANCED_FEATURES = [
  {
    key: "recorder",
    title: chrome.i18n.getMessage("videoRecording"),
    description: chrome.i18n.getMessage("videoRecordingDescription")
  },
  {
    key: "webrtc",
    title: chrome.i18n.getMessage("recordWebRTC"),
    description: chrome.i18n.getMessage("recordWebRTCDescription"),
    reloadRequired: CAT_CATCH_SCRIPT_FEATURES.webrtc.reloadRequired
  },
  {
    key: "recorder2",
    title: chrome.i18n.getMessage("screenCapture"),
    description: chrome.i18n.getMessage("screenCaptureDescription")
  },
  {
    key: "mobileUserAgent",
    title: chrome.i18n.getMessage("mobileUserAgent"),
    description: chrome.i18n.getMessage("mobileUserAgentDescription"),
    reloadRequired: true
  },
  {
    key: "search",
    title: chrome.i18n.getMessage("deepSearch"),
    description: chrome.i18n.getMessage("deepSearchDescription"),
    reloadRequired: CAT_CATCH_SCRIPT_FEATURES.search.reloadRequired
  },
  {
    key: "catch",
    title: chrome.i18n.getMessage("cacheCapture"),
    description: chrome.i18n.getMessage("cacheCaptureDescription"),
    reloadRequired: CAT_CATCH_SCRIPT_FEATURES.catch.reloadRequired
  }
];

// src/background/constants.ts
var PROTOCOL_VERSION = 2;
var RECONNECT_ALARM = "gd-reconnect";
var RESOURCE_LIMIT = 120;
var HEADER_SNAPSHOT_LIMIT = 80;
var HEADER_EXPIRATION_MS = 2 * 60 * 1e3;
var BRIDGE_PERSIST_DEBOUNCE_MS = 240;
var MAIN_FRAME_ID = 0;
var PAIR_TOKEN_KEY = "pairToken";
var SERVER_URL_KEY = "desktopServerUrl";
var SHOULD_TAKE_DOWNLOADS_KEY = "shouldTakeDownloads";
var IS_MEDIA_BUTTON_ENABLED_KEY = "isMediaButtonEnabled";
var MIN_TAKE_SIZE_KB_KEY = "minTakeSizeKB";
var SHOULD_TAKE_UNKNOWN_SIZE_KEY = "shouldTakeUnknownSize";
var SKIP_EXTENSIONS_KEY = "skipExtensions";
var FEATURE_TAB_STATE_KEY = "featureTabState";
var BRIDGE_RESOURCE_CACHE_KEY = "bridgeResourceCacheByTab";
var BRIDGE_HEADER_SNAPSHOTS_KEY = "bridgeHeaderSnapshots";
var BRIDGE_LAST_ACTIVE_TAB_KEY = "bridgeLastActiveTabId";
var FEATURE_KEYS = ADVANCED_FEATURES.map((item) => item.key);

// src/background/chrome-helpers.ts
var bridgeStorage = chrome.storage.session ?? chrome.storage.local;
async function loadLocalState(defaults) {
  const items = await chrome.storage.local.get(defaults);
  return items;
}
async function saveLocalState(values) {
  await chrome.storage.local.set(values);
}
async function loadSessionState(defaults) {
  const items = await bridgeStorage.get(defaults);
  return items;
}
async function saveSessionState(values) {
  await bridgeStorage.set(values);
}
async function queryTabs(queryInfo) {
  return chrome.tabs.query(queryInfo);
}
async function findTab(tabId) {
  try {
    return await chrome.tabs.get(tabId);
  } catch {
    return null;
  }
}
async function sendMessageToTab(tabId, message, options) {
  const tab = await findTab(tabId);
  if (!tab?.id) {
    return {
      status: "no_receiver",
      message: chrome.i18n.getMessage("errorTargetTabNotFound")
    };
  }
  return new Promise((resolve) => {
    chrome.tabs.sendMessage(tabId, message, options ?? {}, (response) => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        const text = String(lastError.message || "");
        const status = /receiving end does not exist/i.test(text) ? "no_receiver" : "runtime_error";
        resolve({
          status,
          message: text
        });
        return;
      }
      if (typeof response === "undefined") {
        resolve({
          status: "no_response"
        });
        return;
      }
      resolve({
        status: "ok",
        response
      });
    });
  });
}
async function reloadTab(tabId) {
  return new Promise((resolve) => {
    chrome.tabs.reload(tabId, { bypassCache: true }, () => resolve());
  });
}
async function cancelDownload(downloadId) {
  return new Promise((resolve, reject) => {
    chrome.downloads.cancel(downloadId, () => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      resolve();
    });
  });
}
async function eraseDownloadFromHistory(downloadId) {
  return new Promise((resolve, reject) => {
    chrome.downloads.erase({ id: downloadId }, () => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      resolve();
    });
  });
}
async function openActionPopup() {
  if (!chrome.action?.openPopup) {
    return;
  }
  try {
    await chrome.action.openPopup();
  } catch {
  }
}

// src/background/desktop-bridge.ts
var PAIRING_TIMEOUT_MS = 6e4;
var DEFAULT_REQUEST_TIMEOUT_MS = 12e3;
var MISSING_PAIRING_MESSAGE = chrome.i18n.getMessage("pendingPairing");
function createDesktopBridge(options = {}) {
  let desktopSocket = null;
  let reconnectTimer = null;
  let installType = "";
  let connectionState = "missing_token";
  let connectionMessage = MISSING_PAIRING_MESSAGE;
  let desktopVersion = "";
  let pairToken = "";
  let serverUrl = DEFAULT_SERVER_URL;
  let taskSnapshot = [];
  const pendingRequests = /* @__PURE__ */ new Map();
  let shouldRetryPairing = false;
  function setInstallType(type) {
    installType = type;
  }
  function buildRequestId() {
    return crypto.randomUUID();
  }
  function setConnectionState(state, message) {
    connectionState = state;
    connectionMessage = message;
  }
  function rejectPendingRequests(message) {
    for (const [requestId, pending] of pendingRequests.entries()) {
      clearTimeout(pending.timeoutId);
      pending.reject(new Error(message));
      pendingRequests.delete(requestId);
    }
  }
  function isReady() {
    return connectionState === "connected" && desktopSocket?.readyState === WebSocket.OPEN;
  }
  function clearReconnectTimer() {
    if (reconnectTimer !== null) {
      clearTimeout(reconnectTimer);
      reconnectTimer = null;
    }
  }
  function scheduleReconnect() {
    if (!pairToken || reconnectTimer !== null) {
      return;
    }
    reconnectTimer = self.setTimeout(() => {
      reconnectTimer = null;
      void connect();
    }, 2500);
  }
  function onDesktopMessage(rawData) {
    let message;
    try {
      message = JSON.parse(rawData);
    } catch {
      return;
    }
    if (message.type === "hello_ack") {
      desktopVersion = String(message.appVersion ?? "");
      setConnectionState("connected", chrome.i18n.getMessage("connected"));
      desktopSocket?.send(JSON.stringify({ type: "subscribe_tasks" }));
      options.onConnected?.();
      return;
    }
    if (message.type === "reload") {
      chrome.runtime.reload();
      return;
    }
    if (message.type === "task_snapshot" && Array.isArray(message.tasks)) {
      taskSnapshot = message.tasks;
      options.onTaskSnapshotChanged?.(taskSnapshot);
      return;
    }
    if (message.type === "task_action_result") {
      const requestId = String(message.requestId ?? "");
      const pending = pendingRequests.get(requestId);
      if (!pending) {
        return;
      }
      clearTimeout(pending.timeoutId);
      pendingRequests.delete(requestId);
      pending.resolve(message);
      return;
    }
    if (message.type === "create_task_result") {
      const requestId = String(message.requestId ?? "");
      const pending = pendingRequests.get(requestId);
      if (!pending) {
        return;
      }
      clearTimeout(pending.timeoutId);
      pendingRequests.delete(requestId);
      const ok = message.status === "created" || message.status === "drafted";
      pending.resolve({
        ok,
        taskId: String(message.taskId ?? ""),
        message: String(message.message ?? "")
      });
      return;
    }
    if (message.type === "error" && connectionState === "authenticating") {
      const text = String(message.message ?? chrome.i18n.getMessage("errorInvalidPairToken"));
      desktopVersion = "";
      taskSnapshot = [];
      setConnectionState("unauthorized", text);
      rejectPendingRequests(text);
      desktopSocket?.close();
      desktopSocket = null;
    }
  }
  async function connect(force = false) {
    if (!pairToken) {
      desktopVersion = "";
      taskSnapshot = [];
      setConnectionState("missing_token", MISSING_PAIRING_MESSAGE);
      return;
    }
    if (desktopSocket && desktopSocket.readyState === WebSocket.OPEN && !force) {
      return;
    }
    clearReconnectTimer();
    if (force && desktopSocket) {
      desktopSocket.close();
      desktopSocket = null;
    }
    setConnectionState("connecting", chrome.i18n.getMessage("connecting"));
    const socket = new WebSocket(serverUrl);
    desktopSocket = socket;
    socket.addEventListener("open", () => {
      if (desktopSocket !== socket) {
        return;
      }
      setConnectionState("authenticating", chrome.i18n.getMessage("authenticating"));
      socket.send(
        JSON.stringify({
          type: "hello",
          protocolVersion: PROTOCOL_VERSION,
          token: pairToken,
          extensionVersion: chrome.runtime.getManifest().version,
          clientKind: "browser_extension",
          installType
        })
      );
    });
    socket.addEventListener("message", (event) => {
      if (desktopSocket !== socket) {
        return;
      }
      onDesktopMessage(String(event.data ?? ""));
    });
    socket.addEventListener("close", () => {
      if (desktopSocket !== socket) {
        return;
      }
      desktopSocket = null;
      rejectPendingRequests(chrome.i18n.getMessage("connectionClosed"));
      taskSnapshot = [];
      options.onTaskSnapshotChanged?.([]);
      if (connectionState !== "unauthorized" && connectionState !== "missing_token") {
        desktopVersion = "";
        setConnectionState("disconnected", chrome.i18n.getMessage("disconnected"));
        scheduleReconnect();
      }
    });
    socket.addEventListener("error", () => {
      if (desktopSocket !== socket) {
        return;
      }
      if (connectionState !== "unauthorized") {
        desktopVersion = "";
        setConnectionState("disconnected", chrome.i18n.getMessage("errorConnectionFailed"));
      }
    });
  }
  async function requestPairing() {
    clearReconnectTimer();
    setConnectionState("connecting", chrome.i18n.getMessage("pairing"));
    let desktopReached = false;
    try {
      const token = await new Promise((resolve, reject) => {
        const socket = new WebSocket(serverUrl);
        let settled = false;
        let timeoutId = 0;
        const finish = (done) => {
          if (settled) {
            return;
          }
          settled = true;
          self.clearTimeout(timeoutId);
          socket.close();
          done();
        };
        timeoutId = self.setTimeout(() => {
          finish(() => reject(new Error(chrome.i18n.getMessage("errorPairingTimeout"))));
        }, PAIRING_TIMEOUT_MS);
        socket.addEventListener("open", () => {
          desktopReached = true;
          socket.send(
            JSON.stringify({
              type: "pair_request",
              requestId: buildRequestId(),
              protocolVersion: PROTOCOL_VERSION,
              extensionVersion: chrome.runtime.getManifest().version,
              clientKind: "browser_extension"
            })
          );
        });
        socket.addEventListener("message", (event) => {
          let response;
          try {
            response = JSON.parse(String(event.data ?? ""));
          } catch {
            return;
          }
          if (response.type !== "pair_result") {
            return;
          }
          if (!response.ok) {
            finish(() => reject(new Error(response.message || chrome.i18n.getMessage("errorPairingRejected"))));
            return;
          }
          const token2 = String(response.token ?? "").trim();
          if (!token2) {
            finish(() => reject(new Error(chrome.i18n.getMessage("errorNoTokenReturned"))));
            return;
          }
          finish(() => resolve(token2));
        });
        socket.addEventListener("close", () => {
          finish(() => reject(new Error(chrome.i18n.getMessage("errorPairingDisconnected"))));
        });
        socket.addEventListener("error", () => {
          finish(() => reject(new Error(chrome.i18n.getMessage("errorConnectionFailed"))));
        });
      });
      shouldRetryPairing = false;
      await setToken(token);
    } catch (error) {
      shouldRetryPairing = !desktopReached;
      const message = error instanceof Error ? error.message : chrome.i18n.getMessage("errorAutoPairingFailed");
      setConnectionState(pairToken ? "disconnected" : "missing_token", message);
      throw error;
    }
  }
  async function sendRequest(payload, timeoutMs) {
    if (!isReady() || !desktopSocket) {
      throw new Error(chrome.i18n.getMessage("disconnected"));
    }
    const requestId = String(payload.requestId ?? buildRequestId());
    const message = { ...payload, requestId };
    const effectiveTimeout = timeoutMs ?? DEFAULT_REQUEST_TIMEOUT_MS;
    return new Promise((resolve, reject) => {
      const timeoutId = self.setTimeout(() => {
        pendingRequests.delete(requestId);
        reject(new Error(chrome.i18n.getMessage("errorResponseTimeout")));
      }, effectiveTimeout);
      pendingRequests.set(requestId, {
        resolve: (value) => resolve(value),
        reject,
        timeoutId
      });
      desktopSocket?.send(JSON.stringify(message));
    });
  }
  async function loadPersistentState() {
    const localState = await loadLocalState({
      [PAIR_TOKEN_KEY]: "",
      [SERVER_URL_KEY]: DEFAULT_SERVER_URL
    });
    pairToken = String(localState[PAIR_TOKEN_KEY] ?? "").trim();
    serverUrl = String(localState[SERVER_URL_KEY] ?? DEFAULT_SERVER_URL).trim() || DEFAULT_SERVER_URL;
  }
  async function setToken(token) {
    pairToken = String(token ?? "").trim();
    await saveLocalState({ [PAIR_TOKEN_KEY]: pairToken });
    if (pairToken) {
      await connect(true);
      return;
    }
    desktopVersion = "";
    taskSnapshot = [];
    if (desktopSocket) {
      desktopSocket.close();
      desktopSocket = null;
    }
    setConnectionState("missing_token", MISSING_PAIRING_MESSAGE);
  }
  async function setServerUrl(nextServerUrl) {
    serverUrl = String(nextServerUrl ?? DEFAULT_SERVER_URL).trim() || DEFAULT_SERVER_URL;
    await saveLocalState({ [SERVER_URL_KEY]: serverUrl });
    await connect(true);
  }
  function onLocalStorageChanged(changes) {
    if (changes[PAIR_TOKEN_KEY]) {
      pairToken = String(changes[PAIR_TOKEN_KEY].newValue ?? "").trim();
    }
    if (changes[SERVER_URL_KEY]) {
      serverUrl = String(changes[SERVER_URL_KEY].newValue ?? DEFAULT_SERVER_URL).trim() || DEFAULT_SERVER_URL;
    }
  }
  function buildSnapshot() {
    return {
      connectionState,
      connectionMessage,
      desktopVersion,
      token: pairToken,
      serverUrl,
      tasks: taskSnapshot
    };
  }
  function setupReconnectAlarm() {
    chrome.alarms.create(RECONNECT_ALARM, { periodInMinutes: 1 });
  }
  function onReconnectAlarm(alarm) {
    if (alarm.name !== RECONNECT_ALARM || connectionState === "connected") {
      return;
    }
    if (!pairToken && shouldRetryPairing) {
      void requestPairing().catch(() => {
      });
      return;
    }
    void connect();
  }
  return {
    buildSnapshot,
    connect,
    setupReconnectAlarm,
    onReconnectAlarm,
    isReady,
    loadPersistentState,
    requestPairing,
    sendRequest,
    setInstallType,
    setServerUrl,
    setToken,
    onLocalStorageChanged
  };
}

// src/background/feature-bridge.ts
var SCRIPT_FEATURE_KEYS = Object.keys(CAT_CATCH_SCRIPT_FEATURES);
var FLUENT_PANEL_FEATURES = /* @__PURE__ */ new Set(["recorder", "webrtc", "catch"]);
function createFeatureBridge() {
  const featureTabs = Object.fromEntries(
    FEATURE_KEYS.map((key) => [key, /* @__PURE__ */ new Set()])
  );
  function createFeatureStateMap(tabId) {
    return FEATURE_KEYS.reduce((state, key) => {
      state[key] = tabId != null && featureTabs[key].has(tabId);
      return state;
    }, {});
  }
  async function saveFeatureTabs() {
    await saveLocalState({
      [FEATURE_TAB_STATE_KEY]: Object.fromEntries(FEATURE_KEYS.map((key) => [key, Array.from(featureTabs[key])]))
    });
  }
  async function setSessionRule(tabId, enabled) {
    return new Promise((resolve, reject) => {
      chrome.declarativeNetRequest.updateSessionRules(
        enabled ? {
          removeRuleIds: [tabId],
          addRules: [
            {
              id: tabId,
              action: {
                type: "modifyHeaders",
                requestHeaders: [
                  {
                    header: "User-Agent",
                    operation: "set",
                    value: MOBILE_USER_AGENT
                  }
                ]
              },
              condition: {
                tabIds: [tabId],
                resourceTypes: Object.values(chrome.declarativeNetRequest.ResourceType)
              }
            }
          ]
        } : {
          removeRuleIds: [tabId]
        },
        () => {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            reject(new Error(lastError.message));
            return;
          }
          resolve();
        }
      );
    });
  }
  async function runScriptFiles(tabId, key, frameIds) {
    const feature = CAT_CATCH_SCRIPT_FEATURES[key];
    const usesFluentPanel = FLUENT_PANEL_FEATURES.has(key);
    const target = feature.allFrames ? frameIds ? { tabId, frameIds } : { tabId, allFrames: true } : { tabId, frameIds: frameIds ?? [MAIN_FRAME_ID] };
    const world = feature.world;
    const files = [
      ...feature.i18n ? ["catch-script/i18n.js"] : [],
      ...usesFluentPanel ? ["catch-script/fluent-ui.js"] : [],
      `catch-script/${feature.script}`
    ];
    if (usesFluentPanel) {
      await chrome.scripting.executeScript({
        args: [chrome.runtime.getURL("icon48.png")],
        func: (iconUrl) => {
          Reflect.set(window, "CatCatchFluentUIIcon", iconUrl);
        },
        injectImmediately: true,
        target,
        world
      });
    }
    await chrome.scripting.executeScript({
      files,
      injectImmediately: true,
      target,
      world
    });
  }
  async function setFeatureEnabled(key, tabId, enabled) {
    if (key === "mobileUserAgent") {
      if (enabled) {
        featureTabs.mobileUserAgent.add(tabId);
      } else {
        featureTabs.mobileUserAgent.delete(tabId);
      }
      await setSessionRule(tabId, enabled);
      await saveFeatureTabs();
      await reloadTab(tabId);
      return enabled ? chrome.i18n.getMessage("mobileUserAgentEnabled") : chrome.i18n.getMessage("mobileUserAgentDisabled");
    }
    const scriptKey = key;
    if (enabled) {
      featureTabs[scriptKey].add(tabId);
    } else {
      featureTabs[scriptKey].delete(tabId);
    }
    await saveFeatureTabs();
    if (CAT_CATCH_SCRIPT_FEATURES[scriptKey].reloadRequired) {
      await reloadTab(tabId);
      return enabled ? chrome.i18n.getMessage("featureEnabledAfterReload") : chrome.i18n.getMessage("featureDisabled");
    }
    if (!enabled) {
      return chrome.i18n.getMessage("featureBackgroundDisabled");
    }
    await runScriptFiles(tabId, scriptKey);
    return chrome.i18n.getMessage("featureEnabled");
  }
  async function loadPersistentState() {
    const localState = await loadLocalState({
      [FEATURE_TAB_STATE_KEY]: {}
    });
    const storedFeatureTabs = localState[FEATURE_TAB_STATE_KEY] ?? {};
    for (const key of FEATURE_KEYS) {
      featureTabs[key] = new Set((storedFeatureTabs[key] ?? []).filter((value) => Number.isInteger(value)));
    }
    const liveTabs = await queryTabs({});
    const liveTabIds = new Set(liveTabs.filter((tab) => tab.id != null).map((tab) => tab.id));
    for (const key of FEATURE_KEYS) {
      for (const tabId of featureTabs[key]) {
        if (liveTabIds.has(tabId)) {
          continue;
        }
        featureTabs[key].delete(tabId);
        if (key === "mobileUserAgent") {
          void setSessionRule(tabId, false).catch(() => {
          });
        }
      }
    }
    for (const tabId of featureTabs.mobileUserAgent) {
      try {
        await setSessionRule(tabId, true);
      } catch {
        featureTabs.mobileUserAgent.delete(tabId);
      }
    }
    await saveFeatureTabs();
  }
  async function toggleFeature(key, tabId) {
    const enabled = !featureTabs[key].has(tabId);
    return setFeatureEnabled(key, tabId, enabled);
  }
  async function onBridgeScriptCommand(payload, sender) {
    if (payload.Message !== "script" || typeof payload.script !== "string") {
      return;
    }
    const tabId = sender.tab?.id;
    const scriptKey = payload.script.replace(/\.js$/i, "");
    if (!tabId || !SCRIPT_FEATURE_KEYS.includes(scriptKey) || !featureTabs[scriptKey].has(tabId)) {
      return;
    }
    await setFeatureEnabled(scriptKey, tabId, false);
  }
  function onTabRemoved(tabId) {
    for (const key of FEATURE_KEYS) {
      featureTabs[key].delete(tabId);
    }
    void setSessionRule(tabId, false).catch(() => {
    });
    void saveFeatureTabs();
  }
  function onNavigationCommitted(details) {
    if (details.tabId <= 0 || !/^https?:/i.test(details.url)) {
      return;
    }
    if (featureTabs.mobileUserAgent.has(details.tabId)) {
      void chrome.scripting.executeScript({
        args: [MOBILE_USER_AGENT],
        target: { tabId: details.tabId, frameIds: [details.frameId] },
        func: (userAgent) => {
          Object.defineProperty(navigator, "userAgent", { value: userAgent, writable: false });
        },
        injectImmediately: true,
        world: "MAIN"
      }).catch(() => {
      });
    }
    for (const key of SCRIPT_FEATURE_KEYS) {
      if (!featureTabs[key].has(details.tabId)) {
        continue;
      }
      const feature = CAT_CATCH_SCRIPT_FEATURES[key];
      if (!feature.allFrames && details.frameId !== MAIN_FRAME_ID) {
        continue;
      }
      void runScriptFiles(
        details.tabId,
        key,
        feature.allFrames ? [details.frameId] : [MAIN_FRAME_ID]
      ).catch(() => {
      });
    }
  }
  return {
    createFeatureStateMap,
    onBridgeScriptCommand,
    onNavigationCommitted,
    onTabRemoved,
    loadPersistentState,
    toggleFeature
  };
}

// src/shared/utils.ts
var IMAGE_EXTENSIONS = /* @__PURE__ */ new Set(["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif", "heic"]);
var ARCHIVE_EXTENSIONS = /* @__PURE__ */ new Set(["zip", "7z", "rar", "tar", "gz", "bz2", "xz"]);
var PDF_EXTENSIONS = /* @__PURE__ */ new Set(["pdf"]);
var SPREADSHEET_EXTENSIONS = /* @__PURE__ */ new Set(["xls", "xlsx", "csv", "tsv", "ods", "numbers"]);
var DOCUMENT_EXTENSIONS = /* @__PURE__ */ new Set([
  "txt",
  "md",
  "rtf",
  "doc",
  "docx",
  "ppt",
  "pptx",
  "pages",
  "key",
  "epub"
]);
function truncate(text, max = 44) {
  if (!text || text.length <= max) {
    return text;
  }
  return `${text.slice(0, Math.max(0, max - 3))}...`;
}
function domainFromUrl(value) {
  try {
    return new URL(value).hostname;
  } catch {
    return "";
  }
}
function mimeFromUrl(value) {
  try {
    const mime = new URL(value).searchParams.get("mime_type")?.replace(/_/g, "/").toLowerCase() ?? "";
    return isCatCatchMedia("", mime) ? mime : "";
  } catch {
    return "";
  }
}
function filenameFromUrl(value) {
  try {
    const url = new URL(value);
    return decodeURIComponent(url.pathname.split("/").pop() || "");
  } catch {
    return "";
  }
}
function fileExtension(name) {
  const dotIndex = name.lastIndexOf(".");
  return dotIndex < 0 ? "" : name.slice(dotIndex + 1).toLowerCase();
}
function parserHintOf(url, mime, extension) {
  const loweredUrl = url.toLowerCase();
  const loweredMime = mime.toLowerCase();
  const loweredExt = extension.toLowerCase();
  if (isCatCatchM3u8(loweredExt, loweredMime) || loweredUrl.includes(".m3u8")) {
    return "m3u8";
  }
  if (isCatCatchMpd(loweredExt, loweredMime) || loweredUrl.includes(".mpd")) {
    return "mpd";
  }
  if (isCatCatchMedia(loweredExt, loweredMime)) {
    return "media";
  }
  if (["zip", "7z", "rar", "pdf", "exe", "msi", "dmg", "pkg", "apk", "iso"].includes(loweredExt)) {
    return "download";
  }
  return "other";
}
function dashTrackRoleOf(filename, url) {
  const name = filename || filenameFromUrl(url);
  const lowered = `${name} ${url}`.toLowerCase();
  if (/(^|[-_.\\/])(video)([-_.\\/]|$)/i.test(lowered)) {
    return "video";
  }
  if (/(^|[-_.\\/])(audio)([-_.\\/]|$)/i.test(lowered)) {
    return "audio";
  }
  const match = lowered.match(/-(\d{5,6})(?=\.m4s(?:$|[?#]))/i) ?? lowered.match(/\/(\d{5,6})(?=\.m4s(?:$|[?#]))/i);
  const trackId = Number(match?.[1] ?? 0);
  if (!Number.isFinite(trackId) || trackId <= 0) {
    return "";
  }
  if (trackId >= 1e5) {
    return "video";
  }
  if (trackId >= 3e4 && trackId < 4e4) {
    return "audio";
  }
  return "";
}
function mediaKindOf(resource, extension) {
  const mime = resource.mime.toLowerCase();
  if (extension === "m4s") {
    const dashKind = dashTrackRoleOf(resource.filename, resource.url);
    if (dashKind) {
      return dashKind;
    }
  }
  if (mime.startsWith("video/")) {
    return "video";
  }
  if (mime.startsWith("audio/")) {
    return "audio";
  }
  if (CAT_CATCH_VIDEO_EXTENSIONS.has(extension) && !CAT_CATCH_AUDIO_EXTENSIONS.has(extension)) {
    return "video";
  }
  if (CAT_CATCH_AUDIO_EXTENSIONS.has(extension) && !CAT_CATCH_VIDEO_EXTENSIONS.has(extension)) {
    return "audio";
  }
  return "";
}
function visualKindOf({
  extension,
  mime,
  parserHint,
  filename,
  url
}) {
  const loweredMime = mime?.toLowerCase() ?? "";
  const loweredExtension = extension.toLowerCase();
  if (parserHint === "m3u8" || parserHint === "mpd") {
    return "stream";
  }
  if (loweredExtension === "m4s" && filename && url) {
    const role = dashTrackRoleOf(filename, url);
    if (role === "audio") {
      return "audio";
    }
    if (role === "video") {
      return "video";
    }
  }
  if (loweredMime.startsWith("video/") || CAT_CATCH_VIDEO_EXTENSIONS.has(loweredExtension)) {
    return "video";
  }
  if (loweredMime.startsWith("audio/") || CAT_CATCH_AUDIO_EXTENSIONS.has(loweredExtension)) {
    return "audio";
  }
  if (loweredMime.startsWith("image/") || IMAGE_EXTENSIONS.has(loweredExtension)) {
    return "image";
  }
  if (ARCHIVE_EXTENSIONS.has(loweredExtension)) {
    return "archive";
  }
  if (PDF_EXTENSIONS.has(loweredExtension) || loweredMime === "application/pdf") {
    return "pdf";
  }
  if (SPREADSHEET_EXTENSIONS.has(loweredExtension) || loweredMime.includes("spreadsheet") || loweredMime.includes("excel") || loweredMime.includes("csv")) {
    return "spreadsheet";
  }
  if (DOCUMENT_EXTENSIONS.has(loweredExtension) || loweredMime.startsWith("text/")) {
    return "document";
  }
  return "download";
}
function resourcePresentationParts(resource) {
  const extension = fileExtension(resource.filename || filenameFromUrl(resource.url));
  return {
    extension,
    parserHint: parserHintOf(resource.url, resource.mime, extension),
    deliveryTarget: resource.url.startsWith("blob:") ? "browser_download" : "desktop",
    mediaKind: mediaKindOf(resource, extension)
  };
}
function resourcePrimaryBadge(resource, parts = resourcePresentationParts(resource)) {
  if (parts.parserHint === "m3u8") {
    return "M3U8";
  }
  if (parts.parserHint === "mpd") {
    return "MPD";
  }
  if (parts.extension) {
    return parts.extension.slice(0, 6).toUpperCase();
  }
  if (resource.mime.startsWith("audio/")) {
    return chrome.i18n.getMessage("audio");
  }
  if (resource.mime.startsWith("video/")) {
    return chrome.i18n.getMessage("video");
  }
  return chrome.i18n.getMessage("resource");
}
function describeResource(resource) {
  const parts = resourcePresentationParts(resource);
  const mime = resource.mime.toLowerCase();
  let category = "all";
  if (parts.parserHint === "m3u8" || parts.parserHint === "mpd" || parts.mediaKind === "video") {
    category = "video";
  } else if (parts.mediaKind === "audio") {
    category = "audio";
  }
  const primaryBadge = resourcePrimaryBadge(resource, parts);
  const needsDesktop = parts.deliveryTarget === "desktop";
  const statusText = resource.sentToDesktopAt ? needsDesktop ? chrome.i18n.getMessage("sentToDesktop") : chrome.i18n.getMessage("sentToBrowserDownload") : needsDesktop ? chrome.i18n.getMessage("sendToDesktop") : chrome.i18n.getMessage("browserDownload");
  const tags = [primaryBadge];
  if (parts.deliveryTarget === "browser_download") {
    tags.push(chrome.i18n.getMessage("browserDownload"));
  }
  if (isDashSegment(resource)) {
    const role = dashTrackRoleOf(resource.filename, resource.url);
    if (role === "video") {
      tags.push(chrome.i18n.getMessage("videoTrack"));
    } else if (role === "audio") {
      tags.push(chrome.i18n.getMessage("audioTrack"));
    }
  }
  const visual = {
    kind: visualKindOf({
      extension: parts.extension,
      mime,
      parserHint: parts.parserHint,
      filename: resource.filename,
      url: resource.url
    })
  };
  return {
    extension: parts.extension,
    parserHint: parts.parserHint,
    deliveryTarget: parts.deliveryTarget,
    category,
    primaryBadge,
    statusText,
    actionLabel: needsDesktop ? chrome.i18n.getMessage("sendToDesktop") : chrome.i18n.getMessage("browserDownload"),
    needsDesktop,
    tags,
    visual
  };
}
function isDashSegment(resource) {
  const url = resource.url;
  if (url.includes("/media-audio-") || url.includes("/media-video-")) {
    return true;
  }
  const extension = fileExtension(resource.filename || filenameFromUrl(url));
  return extension === "m4s";
}
function canUseOnlineMerge(resource) {
  const parts = resourcePresentationParts(resource);
  if (parts.deliveryTarget !== "desktop") {
    return false;
  }
  const mime = resource.mime.toLowerCase();
  return parts.parserHint === "m3u8" || parts.parserHint === "mpd" || isCatCatchMedia(parts.extension, mime) || mime.endsWith("octet-stream");
}
function canUseOnlineMergeSelection(resources) {
  return resources.length === 2 && resources.every(canUseOnlineMerge);
}
function sortResourcesForOnlineMerge(resources) {
  return [...resources].sort((left, right) => {
    const leftCategory = describeResource(left).category;
    const rightCategory = describeResource(right).category;
    if (leftCategory === rightCategory) {
      return 0;
    }
    if (leftCategory === "video") {
      return -1;
    }
    if (rightCategory === "video") {
      return 1;
    }
    return 0;
  });
}

// src/background/media-bridge.ts
function createMediaBridge() {
  let mediaSnapshot = null;
  function createEmptyPlaybackState(message = chrome.i18n.getMessage("noControllableMediaDetected")) {
    return {
      isAvailable: false,
      message,
      tabId: null,
      mediaIndex: -1,
      currentTime: 0,
      duration: 0,
      progress: 0,
      volume: 1,
      isPaused: true,
      shouldLoop: false,
      isMuted: false,
      speed: 1
    };
  }
  function createEmptyMediaPanelState(message) {
    return {
      mediaItems: [],
      playbackState: createEmptyPlaybackState(message)
    };
  }
  function createMediaItems(srcList, count) {
    return Array.from({ length: count }, (_unused, index) => {
      const src = srcList[index] ?? `media-${index + 1}`;
      return {
        index,
        label: truncate(filenameFromUrl(src) || src.split("/").pop() || src, 48)
      };
    });
  }
  function mediaFailureMessage(result) {
    switch (result.status) {
      case "no_receiver":
        return chrome.i18n.getMessage("mediaBridgeNotReady");
      case "runtime_error":
        return result.message || chrome.i18n.getMessage("errorReadMediaStateFailed");
      case "no_response":
        return chrome.i18n.getMessage("noMediaStateResponse");
      default:
        return chrome.i18n.getMessage("pageNoControllableMedia");
    }
  }
  function buildPlaybackState(tabId, index, state) {
    return {
      isAvailable: true,
      message: "",
      tabId,
      mediaIndex: index,
      currentTime: Number(state.currentTime ?? 0),
      duration: Number(state.duration ?? 0),
      progress: Number(state.time ?? 0),
      volume: Number(state.volume ?? 1),
      isPaused: Boolean(state.paused ?? true),
      shouldLoop: Boolean(state.loop ?? false),
      isMuted: Boolean(state.muted ?? false),
      speed: Number(state.speed ?? 1)
    };
  }
  async function requestMediaState(tabId, index) {
    return sendMessageToTab(
      tabId,
      { Message: "getVideoState", index },
      { frameId: MAIN_FRAME_ID }
    );
  }
  async function sendMediaCommand(tabId, message) {
    const result = await sendMessageToTab(tabId, message, { frameId: MAIN_FRAME_ID });
    if (result.status === "no_receiver") {
      throw new Error(chrome.i18n.getMessage("mediaBridgeNotReady"));
    }
  }
  function buildMediaMessage(action, value, snapshot) {
    const { index, playbackState } = snapshot;
    switch (action) {
      case "toggle_play":
        return { Message: playbackState.isPaused ? "play" : "pause", index };
      case "set_speed":
        return { Message: "speed", speed: Number(value ?? 1), index };
      case "pip":
        return { Message: "pip", index };
      case "screenshot":
        return { Message: "screenshot", index };
      case "toggle_loop":
        return { Message: "loop", action: Boolean(value), index };
      case "toggle_muted":
        return { Message: "muted", action: Boolean(value), index };
      case "set_volume":
        return { Message: "setVolume", volume: Number(value ?? 1), index };
      case "set_time":
        return { Message: "setTime", time: Number(value ?? 0), index };
      case "fullscreen":
        return null;
      default: {
        const exhaustive = action;
        void exhaustive;
        return null;
      }
    }
  }
  async function buildPanelState(activeTabId) {
    const tabId = activeTabId;
    if (!tabId) {
      return createEmptyMediaPanelState(chrome.i18n.getMessage("noActiveTabForMedia"));
    }
    let mediaIndex = mediaSnapshot?.tabId === tabId ? mediaSnapshot.index : 0;
    const result = await requestMediaState(tabId, mediaIndex >= 0 ? mediaIndex : 0);
    const state = result.response;
    if (result.status !== "ok" || !state?.count) {
      mediaSnapshot = null;
      return createEmptyMediaPanelState(mediaFailureMessage(result));
    }
    const count = Number(state.count ?? 0);
    mediaIndex = mediaIndex >= 0 && mediaIndex < count ? mediaIndex : 0;
    const srcList = Array.isArray(state.src) ? state.src : [];
    const playbackState = buildPlaybackState(tabId, mediaIndex, state);
    mediaSnapshot = { tabId, index: mediaIndex, playbackState };
    return {
      mediaItems: createMediaItems(srcList, count),
      playbackState
    };
  }
  async function runAction(action, value) {
    if (!mediaSnapshot) {
      throw new Error(chrome.i18n.getMessage("noControllableMedia"));
    }
    const tabId = mediaSnapshot.tabId;
    const index = mediaSnapshot.index;
    const current = mediaSnapshot.playbackState;
    if (action === "toggle_play") {
      const probe = await requestMediaState(tabId, index);
      if (probe.status === "ok" && probe.response?.count) {
        const fresh = buildPlaybackState(tabId, index, probe.response);
        mediaSnapshot = { tabId, index, playbackState: fresh };
      }
    }
    const message = buildMediaMessage(action, value, mediaSnapshot);
    if (!message) {
      return current;
    }
    if (action === "set_volume" && typeof value === "number" && value > 0 && mediaSnapshot.playbackState.isMuted) {
      await sendMediaCommand(tabId, { Message: "muted", action: false, index });
    }
    await sendMediaCommand(tabId, message);
    const optimistic = { ...mediaSnapshot.playbackState };
    switch (action) {
      case "toggle_play":
        optimistic.isPaused = !mediaSnapshot.playbackState.isPaused;
        break;
      case "set_speed":
        optimistic.speed = Number(value ?? 1);
        break;
      case "set_volume":
        optimistic.volume = Number(value ?? 1);
        optimistic.isMuted = false;
        break;
      case "set_time":
        optimistic.currentTime = Number(value ?? 0);
        break;
      case "toggle_loop":
        optimistic.shouldLoop = Boolean(value);
        break;
      case "toggle_muted":
        optimistic.isMuted = Boolean(value);
        break;
    }
    mediaSnapshot = { tabId, index, playbackState: optimistic };
    return optimistic;
  }
  function setMediaIndex(tabId, index) {
    if (!mediaSnapshot || mediaSnapshot.tabId !== tabId) {
      return;
    }
    mediaSnapshot.index = index;
    mediaSnapshot.playbackState.mediaIndex = index;
  }
  function onTabRemoved(tabId) {
    if (mediaSnapshot?.tabId === tabId) {
      mediaSnapshot = null;
    }
  }
  return {
    buildPanelState,
    runAction,
    onTabRemoved,
    setMediaIndex
  };
}

// src/background/download-spec.ts
var MIME_EXTENSIONS = {
  "application/dash+xml": "mpd",
  "application/mpegurl": "m3u8",
  "application/vnd.apple.mpegurl": "m3u8",
  "application/x-mpegurl": "m3u8",
  "audio/aac": "aac",
  "audio/flac": "flac",
  "audio/mp4": "m4a",
  "audio/mpeg": "mp3",
  "audio/ogg": "ogg",
  "audio/wav": "wav",
  "audio/webm": "webm",
  "video/mp2t": "ts",
  "video/mp4": "mp4",
  "video/quicktime": "mov",
  "video/webm": "webm",
  "video/x-flv": "flv",
  "video/x-m4v": "m4v",
  "video/x-ms-wmv": "wmv"
};
function cleanFilename(value) {
  return (value ?? "").trim().replace(/[<>:"/\\|?*\x00-\x1f]+/g, " ").replace(/\s+/g, " ").replace(/[. ]+$/g, "").trim().slice(0, 160);
}
function extensionFromMime(mime) {
  const type = mime?.split(";")[0]?.trim().toLowerCase() ?? "";
  return MIME_EXTENSIONS[type] ?? "";
}
function filenameWithExtension(baseName, extension) {
  const trimmedBaseName = cleanFilename(baseName) || "resource";
  const normalizedExt = extension.trim().replace(/^\./, "").toLowerCase();
  if (!normalizedExt) {
    return trimmedBaseName;
  }
  if (fileExtension(trimmedBaseName) === normalizedExt) {
    return trimmedBaseName;
  }
  return `${trimmedBaseName}.${normalizedExt}`;
}
function resourceNameFromCapture(payload) {
  const ext = payload.ext?.trim() || extensionFromMime(payload.mime);
  const explicit = cleanFilename(payload.filename);
  if (explicit) {
    return ext && !fileExtension(explicit) ? filenameWithExtension(explicit, ext) : explicit;
  }
  const fromUrl = cleanFilename(filenameFromUrl(payload.url));
  if (fromUrl) {
    return ext ? filenameWithExtension(fromUrl, ext) : fromUrl;
  }
  return ext ? filenameWithExtension("resource", ext) : "resource";
}
function taskNameForResource(resource) {
  const urlFilename = filenameFromUrl(resource.url);
  const current = cleanFilename(resource.filename || urlFilename);
  const extension = fileExtension(current) || fileExtension(urlFilename) || extensionFromMime(resource.mime);
  const title = cleanFilename(resource.pageTitle);
  const baseName = title || current || "resource";
  return filenameWithExtension(baseName, extension);
}
function toResourceTaskOptions(resource) {
  return {
    url: resource.url,
    headers: resource.requestHeaders,
    filename: taskNameForResource(resource),
    size: resource.size,
    supportsRange: resource.supportsRange
  };
}

// src/background/resource-cache.ts
var HEADER_WHITELIST = /* @__PURE__ */ new Set([
  "accept",
  "accept-language",
  "authorization",
  "cookie",
  "origin",
  "referer",
  "sec-ch-ua",
  "sec-ch-ua-arch",
  "sec-ch-ua-bitness",
  "sec-ch-ua-full-version",
  "sec-ch-ua-full-version-list",
  "sec-ch-ua-mobile",
  "sec-ch-ua-model",
  "sec-ch-ua-platform",
  "sec-ch-ua-platform-version",
  "sec-fetch-dest",
  "sec-fetch-mode",
  "sec-fetch-site",
  "user-agent",
  "priority"
]);
function selectAllowedHeaders(headers) {
  const result = {};
  for (const [key, value] of Object.entries(headers ?? {})) {
    const name = key.trim().toLowerCase();
    if (!HEADER_WHITELIST.has(name)) {
      continue;
    }
    const text = value.trim();
    if (!text) {
      continue;
    }
    result[name] = text;
  }
  return result;
}
function urlWithoutHash(value, allowBlob = false) {
  if (!value) {
    return "";
  }
  if (allowBlob && value.startsWith("blob:")) {
    return value;
  }
  try {
    const url = new URL(value);
    url.hash = "";
    return url.toString();
  } catch {
    return value.split("#", 1)[0] ?? value;
  }
}
function hostOf(url) {
  try {
    return new URL(url).host;
  } catch {
    return null;
  }
}
function sortResources(resources) {
  return [...resources].sort((left, right) => right.capturedAt - left.capturedAt);
}
function resourceFromStorage(resource) {
  return { ...resource, requestHeaders: selectAllowedHeaders(resource.requestHeaders) };
}
function headerSnapshotFromStorage(snapshot) {
  return { ...snapshot, headers: selectAllowedHeaders(snapshot.headers) };
}
var ResourceCache = class {
  resourcesByTab = /* @__PURE__ */ new Map();
  resourcesById = /* @__PURE__ */ new Map();
  headerSnapshotsByUrl = /* @__PURE__ */ new Map();
  awaiters = /* @__PURE__ */ new Map();
  onChange;
  constructor(onChange) {
    this.onChange = onChange;
  }
  add(resource) {
    let resourceMap = this.resourcesByTab.get(resource.tabId);
    if (!resourceMap) {
      resourceMap = /* @__PURE__ */ new Map();
      this.resourcesByTab.set(resource.tabId, resourceMap);
    }
    const existing = resourceMap.get(resource.id);
    const merged = existing ? {
      ...existing,
      ...resource,
      pageTitle: resource.pageTitle || existing.pageTitle,
      pageUrl: resource.pageUrl || existing.pageUrl,
      filename: resource.filename || existing.filename,
      mime: resource.mime || existing.mime,
      size: resource.size > 0 ? resource.size : existing.size,
      supportsRange: resource.supportsRange || existing.supportsRange,
      referer: resource.referer || existing.referer,
      // Fresh cookies/auth/sec-* override stale ones (per-key, like every field above).
      requestHeaders: {
        ...existing.requestHeaders,
        ...resource.requestHeaders
      },
      capturedAt: Math.max(existing.capturedAt, resource.capturedAt),
      sentToDesktopAt: existing.sentToDesktopAt ?? resource.sentToDesktopAt
    } : resource;
    resourceMap.set(merged.id, merged);
    this.resourcesById.set(merged.id, merged);
    const awaiterSet = this.awaiters.get(merged.id);
    if (awaiterSet && awaiterSet.size > 0) {
      this.awaiters.delete(merged.id);
      for (const resolver of awaiterSet) {
        try {
          resolver(merged);
        } catch {
        }
      }
    }
    const mergedUrl = urlWithoutHash(merged.url, true);
    if (mergedUrl && (merged.size > 0 || merged.mime || merged.supportsRange)) {
      for (const related of this.resourcesById.values()) {
        if (related.id === merged.id || !related.id.endsWith(`:${mergedUrl}`)) {
          continue;
        }
        related.size = merged.size > 0 ? merged.size : related.size;
        related.mime = merged.mime || related.mime;
        related.filename = related.filename && related.filename !== "resource" ? related.filename : merged.filename;
        related.supportsRange = merged.supportsRange || related.supportsRange;
      }
    }
    this.removeOverflow(resource.tabId);
    this.onChange();
  }
  resourceById(id) {
    return this.resourcesById.get(id);
  }
  resourceByUrl(url, tabId) {
    const resourceIdSuffix = `:${urlWithoutHash(url, true)}`;
    let matched = null;
    const resources = tabId == null ? this.resourcesById.values() : this.resourcesByTab.get(tabId)?.values() ?? [];
    for (const resource of resources) {
      if (!resource.id.endsWith(resourceIdSuffix)) {
        continue;
      }
      if (matched == null || resource.capturedAt > matched.capturedAt) {
        matched = resource;
      }
    }
    return matched;
  }
  resourcesForTab(tabId) {
    return sortResources(this.resourcesByTab.get(tabId)?.values() ?? []);
  }
  otherResources(activeTabId) {
    const result = [];
    for (const [tabId, resourceMap] of this.resourcesByTab.entries()) {
      if (activeTabId != null && tabId === activeTabId) {
        continue;
      }
      result.push(...resourceMap.values());
    }
    return sortResources(result);
  }
  enrichResource(urls, meta) {
    let changed = false;
    for (const url of urls) {
      const normalizedUrl = urlWithoutHash(url, true);
      for (const resource of this.resourcesById.values()) {
        if (!resource.id.endsWith(`:${normalizedUrl}`)) {
          continue;
        }
        if (meta.duration != null && meta.duration > 0) {
          resource.duration = meta.duration;
        }
        if (meta.videoWidth != null && meta.videoWidth > 0) {
          resource.videoWidth = meta.videoWidth;
        }
        if (meta.videoHeight != null && meta.videoHeight > 0) {
          resource.videoHeight = meta.videoHeight;
        }
        if (meta.posterUrl) {
          resource.posterUrl = meta.posterUrl;
        }
        changed = true;
      }
    }
    if (changed) {
      this.onChange();
    }
  }
  enrichTabPoster(tabId, posterUrl) {
    const resourceMap = this.resourcesByTab.get(tabId);
    if (!resourceMap || !posterUrl) {
      return;
    }
    let changed = false;
    for (const resource of resourceMap.values()) {
      if (!resource.posterUrl) {
        resource.posterUrl = posterUrl;
        changed = true;
      }
    }
    if (changed) {
      this.onChange();
    }
  }
  setSent(id) {
    const resource = this.resourcesById.get(id);
    if (!resource) {
      return;
    }
    resource.sentToDesktopAt = Date.now();
    this.onChange();
  }
  clearTab(tabId) {
    const resourceMap = this.resourcesByTab.get(tabId);
    if (resourceMap) {
      for (const resourceId of resourceMap.keys()) {
        this.resourcesById.delete(resourceId);
      }
      this.resourcesByTab.delete(tabId);
    }
    let headersChanged = false;
    for (const [url, snapshot] of this.headerSnapshotsByUrl.entries()) {
      if (snapshot.tabId === tabId) {
        this.headerSnapshotsByUrl.delete(url);
        headersChanged = true;
      }
    }
    if (resourceMap || headersChanged) {
      this.onChange();
    }
  }
  headerSnapshotByUrl(url) {
    this.removeStaleHeaders();
    return this.headerSnapshotsByUrl.get(url) ?? null;
  }
  setHeaderSnapshot(url, headers, tabId, supportsRange, size = 0) {
    const existing = this.headerSnapshotsByUrl.get(url);
    const mergedHeaders = {
      ...existing?.headers ?? {},
      ...headers
    };
    const mergedSupportsRange = supportsRange || Boolean(existing?.supportsRange);
    const mergedSize = (size > 0 ? size : 0) || existing?.size || 0;
    if (Object.keys(mergedHeaders).length === 0 && !mergedSupportsRange && !mergedSize) {
      return;
    }
    this.headerSnapshotsByUrl.set(url, {
      url,
      headers: mergedHeaders,
      capturedAt: Date.now(),
      tabId: tabId ?? existing?.tabId ?? null,
      supportsRange: mergedSupportsRange,
      size: mergedSize
    });
    this.removeStaleHeaders();
    this.onChange();
  }
  // SPA watch URLs often have no snapshot of their own; fall back to the freshest same-host
  // request that carried a cookie.
  headersForPage(pageUrl) {
    const host = hostOf(pageUrl);
    if (host === null) {
      return {};
    }
    let snapshot = this.headerSnapshotByUrl(pageUrl);
    if (!snapshot?.headers.cookie) {
      let freshest = null;
      for (const candidate of this.headerSnapshotsByUrl.values()) {
        if (!candidate.headers.cookie || hostOf(candidate.url) !== host) {
          continue;
        }
        if (!freshest || candidate.capturedAt > freshest.capturedAt) {
          freshest = candidate;
        }
      }
      snapshot = freshest;
    }
    return { ...snapshot?.headers ?? {} };
  }
  // Lets resourceForMediaUrl wait when a click races ahead of webRequest (SW restart).
  waitForResource(id, timeoutMs) {
    return new Promise((resolve) => {
      let set = this.awaiters.get(id);
      if (!set) {
        set = /* @__PURE__ */ new Set();
        this.awaiters.set(id, set);
      }
      let settled = false;
      const finish = (value) => {
        if (settled) {
          return;
        }
        settled = true;
        set?.delete(resolver);
        if (set && set.size === 0) {
          this.awaiters.delete(id);
        }
        clearTimeout(timer);
        resolve(value);
      };
      const resolver = (resource) => finish(resource);
      set.add(resolver);
      const timer = setTimeout(() => finish(null), timeoutMs);
    });
  }
  toSnapshot() {
    this.removeStaleHeaders();
    const resources = {};
    for (const [tabId, resourceMap] of this.resourcesByTab.entries()) {
      resources[String(tabId)] = sortResources(resourceMap.values()).slice(0, RESOURCE_LIMIT);
    }
    return {
      resources,
      headers: [...this.headerSnapshotsByUrl.values()]
    };
  }
  load(snapshot) {
    this.resourcesByTab.clear();
    this.resourcesById.clear();
    for (const [tabIdText, resources] of Object.entries(snapshot.resources ?? {})) {
      const tabId = Number(tabIdText);
      if (!Number.isInteger(tabId) || tabId <= 0 || !Array.isArray(resources)) {
        continue;
      }
      const resourceMap = /* @__PURE__ */ new Map();
      for (const resource of sortResources(resources.map(resourceFromStorage)).slice(0, RESOURCE_LIMIT)) {
        resourceMap.set(resource.id, resource);
        this.resourcesById.set(resource.id, resource);
      }
      this.resourcesByTab.set(tabId, resourceMap);
    }
    this.headerSnapshotsByUrl.clear();
    for (const snapshotHeader of snapshot.headers ?? []) {
      const normalized = headerSnapshotFromStorage(snapshotHeader);
      if (!normalized.url) {
        continue;
      }
      this.headerSnapshotsByUrl.set(normalized.url, normalized);
    }
    this.removeStaleHeaders();
  }
  removeOverflow(tabId) {
    const resourceMap = this.resourcesByTab.get(tabId);
    if (!resourceMap || resourceMap.size <= RESOURCE_LIMIT) {
      return;
    }
    const keepIds = new Set(sortResources(resourceMap.values()).slice(0, RESOURCE_LIMIT).map((resource) => resource.id));
    for (const resourceId of resourceMap.keys()) {
      if (keepIds.has(resourceId)) {
        continue;
      }
      resourceMap.delete(resourceId);
      this.resourcesById.delete(resourceId);
    }
  }
  removeStaleHeaders() {
    const now = Date.now();
    const snapshots = [...this.headerSnapshotsByUrl.values()].filter((snapshot) => snapshot.url && now - snapshot.capturedAt <= HEADER_EXPIRATION_MS).sort((left, right) => right.capturedAt - left.capturedAt).slice(0, HEADER_SNAPSHOT_LIMIT);
    this.headerSnapshotsByUrl.clear();
    for (const snapshot of snapshots) {
      this.headerSnapshotsByUrl.set(snapshot.url, snapshot);
    }
  }
};

// src/background/resource-bridge.ts
function createResourceBridge(options) {
  let bridgePersistTimer = null;
  let loadedFromStorage = false;
  let lastActiveTabId = null;
  const cache = new ResourceCache(scheduleBridgeStateSave);
  function scheduleBridgeStateSave() {
    if (bridgePersistTimer !== null) {
      return;
    }
    bridgePersistTimer = self.setTimeout(() => {
      bridgePersistTimer = null;
      void saveBridgeState();
    }, BRIDGE_PERSIST_DEBOUNCE_MS);
  }
  async function saveBridgeState() {
    const snapshot = cache.toSnapshot();
    await saveSessionState({
      [BRIDGE_RESOURCE_CACHE_KEY]: snapshot.resources,
      [BRIDGE_HEADER_SNAPSHOTS_KEY]: snapshot.headers,
      [BRIDGE_LAST_ACTIVE_TAB_KEY]: lastActiveTabId ?? 0
    });
  }
  async function flushState() {
    if (bridgePersistTimer === null) {
      return;
    }
    clearTimeout(bridgePersistTimer);
    bridgePersistTimer = null;
    await saveBridgeState();
  }
  function basenameOf(path) {
    const trimmed = path.trim();
    if (!trimmed) {
      return "";
    }
    const slashIndex = Math.max(trimmed.lastIndexOf("/"), trimmed.lastIndexOf("\\"));
    return slashIndex >= 0 ? trimmed.slice(slashIndex + 1) : trimmed;
  }
  function isCapturableUrl(url) {
    return /^https?:/i.test(url);
  }
  function hasSharedPathPrefix(left, right) {
    const normalizedLeft = urlWithoutHash(left);
    const normalizedRight = urlWithoutHash(right);
    if (!normalizedLeft || !normalizedRight) {
      return false;
    }
    return normalizedLeft === normalizedRight || normalizedLeft.startsWith(normalizedRight) || normalizedRight.startsWith(normalizedLeft);
  }
  async function tabIdByPageUrl(pageUrl) {
    const normalizedPageUrl = urlWithoutHash(pageUrl);
    if (!normalizedPageUrl) {
      return null;
    }
    const tabs = await queryTabs({});
    const exactMatch = tabs.find((tab) => tab.id && tab.url && hasSharedPathPrefix(tab.url, normalizedPageUrl));
    if (exactMatch?.id) {
      return exactMatch.id;
    }
    try {
      const initiatorUrl = new URL(normalizedPageUrl);
      const originMatch = tabs.find((tab) => {
        if (!tab.id || !tab.url) {
          return false;
        }
        try {
          return new URL(tab.url).origin === initiatorUrl.origin;
        } catch {
          return false;
        }
      });
      if (originMatch?.id) {
        return originMatch.id;
      }
    } catch {
    }
    return null;
  }
  async function setLastActiveTab(tabId) {
    if (lastActiveTabId === tabId) {
      return;
    }
    lastActiveTabId = tabId;
    scheduleBridgeStateSave();
  }
  async function refreshActiveTabFromBrowser() {
    const tabs = await queryTabs({ active: true, currentWindow: true });
    const tabId = tabs[0]?.id ?? null;
    await setLastActiveTab(tabId);
    return tabId;
  }
  async function currentTabId(preferredTabId = null) {
    if (preferredTabId != null) {
      const preferredTab = await findTab(preferredTabId);
      if (preferredTab?.id) {
        await setLastActiveTab(preferredTab.id);
        return preferredTab.id;
      }
    }
    const activeTabId = await refreshActiveTabFromBrowser();
    if (activeTabId != null) {
      return activeTabId;
    }
    if (lastActiveTabId != null) {
      const current = await findTab(lastActiveTabId);
      if (current?.id) {
        return current.id;
      }
    }
    return null;
  }
  async function tabIdForPageMessage(sender, href) {
    if (sender.tab?.id) {
      await setLastActiveTab(sender.tab.id);
      return sender.tab.id;
    }
    const normalizedHref = href?.trim() ?? "";
    if (normalizedHref) {
      const matchedTabId = await tabIdByPageUrl(normalizedHref);
      if (matchedTabId != null) {
        return matchedTabId;
      }
    }
    return currentTabId();
  }
  async function tabIdForNetworkRequest(details) {
    if (details.tabId > 0) {
      return details.tabId;
    }
    const snapshotTabId = cache.headerSnapshotByUrl(details.url)?.tabId;
    if (snapshotTabId != null) {
      return snapshotTabId;
    }
    const matchedTabId = await tabIdByPageUrl(details.initiator ?? "");
    return matchedTabId ?? currentTabId();
  }
  function toResponseMeta(headers) {
    const meta = { size: 0, mime: "", filename: "", supportsRange: false };
    let contentLengthSize = 0;
    let contentRangeSize = 0;
    for (const header of headers ?? []) {
      const name = (header.name ?? "").toLowerCase();
      const value = (header.value ?? "").trim();
      if (name === "content-length") {
        const size = Number.parseInt(value, 10);
        contentLengthSize = Number.isFinite(size) && size > 0 ? size : contentLengthSize;
      } else if (name === "content-type") {
        meta.mime = value.split(";")[0]?.trim().toLowerCase() ?? "";
      } else if (name === "content-disposition") {
        const match = /filename\*\s*=\s*UTF-8''([^;]+)|filename\s*=\s*"?([^";]+)"?/i.exec(value);
        const filename = match?.[1] ?? match?.[2] ?? "";
        try {
          meta.filename = basenameOf(decodeURIComponent(filename));
        } catch {
          meta.filename = basenameOf(filename);
        }
      } else if (name === "accept-ranges") {
        meta.supportsRange = value.toLowerCase().includes("bytes");
      } else if (name === "content-range") {
        const size = Number.parseInt(value.split("/")[1] ?? "", 10);
        contentRangeSize = Number.isFinite(size) && size > 0 ? size : contentRangeSize;
        meta.supportsRange = true;
      }
    }
    meta.size = contentRangeSize || contentLengthSize;
    return meta;
  }
  function shouldCaptureNetworkResource(details, meta) {
    if (!isCapturableUrl(details.url)) {
      return false;
    }
    const extension = fileExtension(meta.filename || filenameFromUrl(details.url));
    return details.type === "media" || isCatCatchMedia(extension, meta.mime);
  }
  function shouldCaptureRequestResource(details) {
    if (!isCapturableUrl(details.url)) {
      return false;
    }
    return details.type === "media" || isCatCatchMedia(fileExtension(filenameFromUrl(details.url)), mimeFromUrl(details.url));
  }
  function initiatorOf(details) {
    return details.initiator && details.initiator !== "null" ? details.initiator : "";
  }
  async function downloadResourceViaBrowser(resource) {
    const filename = taskNameForResource(resource);
    return new Promise((resolve, reject) => {
      chrome.downloads.download(
        {
          url: resource.url,
          filename
        },
        (downloadId) => {
          const lastError = chrome.runtime.lastError;
          if (lastError) {
            reject(new Error(lastError.message));
            return;
          }
          if (typeof downloadId !== "number") {
            reject(new Error(chrome.i18n.getMessage("errorBrowserNoDownloadId")));
            return;
          }
          resolve();
        }
      );
    });
  }
  async function loadPersistentState() {
    const bridgeState = await loadSessionState({
      [BRIDGE_RESOURCE_CACHE_KEY]: {},
      [BRIDGE_HEADER_SNAPSHOTS_KEY]: [],
      [BRIDGE_LAST_ACTIVE_TAB_KEY]: 0
    });
    cache.load({
      resources: bridgeState[BRIDGE_RESOURCE_CACHE_KEY] ?? {},
      headers: bridgeState[BRIDGE_HEADER_SNAPSHOTS_KEY] ?? []
    });
    lastActiveTabId = Number(bridgeState[BRIDGE_LAST_ACTIVE_TAB_KEY] ?? 0) || null;
    loadedFromStorage = true;
  }
  function addResource(url, tabId, tab, pageUrl, parts) {
    const headerSnapshot = cache.headerSnapshotByUrl(url);
    const headers = {
      ...headerSnapshot?.headers ?? {},
      ...parts.extraHeaders ?? {}
    };
    const referer = headers.referer || pageUrl || tab?.url || "";
    if (referer) {
      headers.referer = referer;
    }
    cache.add({
      id: `${tabId}:${urlWithoutHash(url, true)}`,
      tabId,
      url,
      pageTitle: tab?.title ?? "",
      pageUrl: pageUrl || tab?.url || "",
      filename: parts.filename,
      mime: parts.mime,
      size: parts.size,
      supportsRange: parts.supportsRange || Boolean(headerSnapshot?.supportsRange),
      referer,
      requestHeaders: headers,
      capturedAt: Date.now()
    });
  }
  async function capturePageResource(sender, payload) {
    const tabId = await tabIdForPageMessage(sender, payload.href);
    if (!tabId || !/^(https?:|blob:)/i.test(payload.url)) {
      return;
    }
    const tab = await findTab(tabId);
    addResource(payload.url, tabId, tab, payload.href ?? tab?.url ?? "", {
      filename: resourceNameFromCapture(payload),
      mime: payload.mime?.toLowerCase() || mimeFromUrl(payload.url),
      size: 0,
      supportsRange: false,
      extraHeaders: selectAllowedHeaders(payload.requestHeaders)
    });
  }
  async function captureNetworkResource(details) {
    const meta = toResponseMeta(details.responseHeaders);
    meta.mime = mimeFromUrl(details.url) || meta.mime;
    const responseSupportsRange = meta.supportsRange || details.statusCode === 206;
    if (isCapturableUrl(details.url) && (responseSupportsRange || meta.size > 0)) {
      cache.setHeaderSnapshot(details.url, {}, details.tabId > 0 ? details.tabId : lastActiveTabId, responseSupportsRange, meta.size);
    }
    if (!shouldCaptureNetworkResource(details, meta)) {
      return;
    }
    const tabId = await tabIdForNetworkRequest(details);
    if (!tabId) {
      return;
    }
    const tab = await findTab(tabId);
    addResource(details.url, tabId, tab, initiatorOf(details), {
      filename: meta.filename || basenameOf(filenameFromUrl(details.url)) || "resource",
      mime: meta.mime,
      size: meta.size,
      supportsRange: responseSupportsRange
    });
  }
  async function captureRequestResource(details) {
    if (!shouldCaptureRequestResource(details)) {
      return;
    }
    const tabId = details.tabId > 0 ? details.tabId : lastActiveTabId ?? await currentTabId();
    if (!tabId) {
      return;
    }
    const tab = await findTab(tabId);
    addResource(details.url, tabId, tab, initiatorOf(details), {
      filename: basenameOf(filenameFromUrl(details.url)) || "resource",
      mime: mimeFromUrl(details.url),
      size: 0,
      supportsRange: false
    });
  }
  async function routeBrowserDownload(downloadItem) {
    const finalUrl = downloadItem.finalUrl || downloadItem.url;
    const matchedResource = cache.resourceByUrl(finalUrl) ?? cache.resourceByUrl(downloadItem.url);
    const filename = basenameOf(downloadItem.filename) || basenameOf(matchedResource?.filename ?? "") || basenameOf(filenameFromUrl(finalUrl)) || "resource";
    const headerSnapshot = cache.headerSnapshotByUrl(finalUrl) ?? cache.headerSnapshotByUrl(downloadItem.url);
    const headers = { ...headerSnapshot?.headers ?? {} };
    if (downloadItem.referrer && !headers.referer) {
      headers.referer = downloadItem.referrer;
    }
    try {
      const result = await options.sendDesktopRequest({
        type: "create_task",
        source: "download",
        title: filename,
        payload: {
          url: downloadItem.url,
          headers,
          filename,
          size: typeof downloadItem.totalBytes === "number" && downloadItem.totalBytes > 0 ? downloadItem.totalBytes : matchedResource?.size || headerSnapshot?.size || 0,
          supportsRange: Boolean(
            matchedResource?.supportsRange || headerSnapshot?.supportsRange || downloadItem.canResume === true
          )
        }
      });
      if (result.ok) {
        await openActionPopup();
      }
    } catch {
    }
  }
  async function sendHttpResourceToDesktop(resource) {
    const spec = toResourceTaskOptions(resource);
    try {
      const result = await options.sendDesktopRequest({
        type: "create_task",
        source: "resource",
        title: spec.filename,
        payload: spec
      });
      if (result.ok) {
        cache.setSent(resource.id);
        return {
          ...result,
          message: result.message || chrome.i18n.getMessage("resourceSentToDesktop")
        };
      }
      return result;
    } catch (error) {
      return {
        ok: false,
        message: error instanceof Error ? error.message : chrome.i18n.getMessage("errorSendFailed")
      };
    }
  }
  async function sendResource(resourceId) {
    const resource = cache.resourceById(resourceId) ?? null;
    if (!resource) {
      return { ok: false, message: chrome.i18n.getMessage("errorResourceNotFound") };
    }
    if (resource.url.startsWith("blob:")) {
      try {
        await downloadResourceViaBrowser(resource);
        cache.setSent(resource.id);
        return { ok: true, message: chrome.i18n.getMessage("resourceSentToBrowser") };
      } catch (error) {
        return { ok: false, message: error instanceof Error ? error.message : chrome.i18n.getMessage("errorSendFailed") };
      }
    }
    return sendHttpResourceToDesktop(resource);
  }
  function setMissingReferer(resource, fallback) {
    if (!fallback || resource.requestHeaders.referer || resource.referer) {
      return;
    }
    resource.requestHeaders = { ...resource.requestHeaders, referer: fallback };
    resource.referer = fallback;
  }
  async function resourceForMediaUrl(url, tabId, fallbackTitle, fallbackPageUrl) {
    const id = `${tabId}:${urlWithoutHash(url, true)}`;
    const direct = cache.resourceById(id);
    if (direct) {
      setMissingReferer(direct, fallbackPageUrl);
      return direct;
    }
    const waited = await cache.waitForResource(id, 1500);
    if (waited) {
      setMissingReferer(waited, fallbackPageUrl);
      return waited;
    }
    const snapshot = cache.headerSnapshotByUrl(url);
    const headers = { ...snapshot?.headers ?? {} };
    const referer = headers.referer || fallbackPageUrl;
    if (referer) {
      headers.referer = referer;
    }
    const synthesized = {
      id,
      tabId,
      url,
      pageTitle: fallbackTitle,
      pageUrl: fallbackPageUrl,
      filename: basenameOf(filenameFromUrl(url)) || "resource",
      mime: mimeFromUrl(url),
      size: 0,
      supportsRange: Boolean(snapshot?.supportsRange),
      referer,
      requestHeaders: headers,
      capturedAt: Date.now()
    };
    cache.add(synthesized);
    console.warn(
      "[GD Bridge] resourceForMediaUrl synthesized fallback (no webRequest row within 1500ms)",
      { url: synthesized.url, hasSnapshot: Boolean(snapshot), hasReferer: Boolean(referer) }
    );
    return synthesized;
  }
  async function downloadPageMedia(sender, payload) {
    const tabId = await tabIdForPageMessage(sender, payload.href);
    if (!tabId) {
      return { ok: false, message: chrome.i18n.getMessage("errorNoActiveTab") };
    }
    const selection = payload.selection;
    if (!selection || typeof selection !== "object") {
      return { ok: false, message: chrome.i18n.getMessage("errorInvalidDownloadRequest") };
    }
    const fallbackPageUrl = payload.href || "";
    if (selection.kind === "single" || selection.kind === "stream") {
      if (!selection.url) {
        return { ok: false, message: chrome.i18n.getMessage("errorInvalidDownloadRequest") };
      }
      const resource = await resourceForMediaUrl(selection.url, tabId, payload.title, fallbackPageUrl);
      const result = await sendHttpResourceToDesktop(resource);
      if (result.ok) {
        await openActionPopup();
      }
      return result;
    }
    if (selection.kind === "merge") {
      if (!selection.video || !selection.audio) {
        return { ok: false, message: chrome.i18n.getMessage("errorInvalidMergeRequest") };
      }
      const [video, audio] = await Promise.all([
        resourceForMediaUrl(selection.video, tabId, payload.title, fallbackPageUrl),
        resourceForMediaUrl(selection.audio, tabId, payload.title, fallbackPageUrl)
      ]);
      const result = await sendMergeResources([video, audio]);
      if (result.ok) {
        await openActionPopup();
      }
      return result;
    }
    if (selection.kind === "external") {
      if (!selection.pageUrl) {
        return { ok: false, message: chrome.i18n.getMessage("errorInvalidDownloadRequest") };
      }
      const result = await sendExternalDownload(selection, payload.title, fallbackPageUrl);
      if (result.ok) {
        await openActionPopup();
      }
      return result;
    }
    return { ok: false, message: chrome.i18n.getMessage("errorUnknownDownloadType") };
  }
  async function sendExternalDownload(selection, title, fallbackPageUrl) {
    return options.sendDesktopRequest({
      type: "create_task",
      source: "page_media",
      title: title || "",
      payload: {
        url: selection.pageUrl,
        pageUrl: fallbackPageUrl || selection.pageUrl,
        pageTitle: title || "",
        headers: cache.headersForPage(selection.pageUrl)
      }
    }, 12e4);
  }
  function mergeOutputTitle(resources) {
    const pageTitle = (resources[0]?.pageTitle ?? "").trim();
    if (pageTitle) {
      return pageTitle;
    }
    const firstFileName = basenameOf(resources[0]?.filename || filenameFromUrl(resources[0]?.url || ""));
    if (firstFileName) {
      const extension = fileExtension(firstFileName);
      return extension ? firstFileName.slice(0, -(extension.length + 1)) : firstFileName;
    }
    return "merged-media";
  }
  async function sendMergeResources(resources) {
    if (resources.length !== 2) {
      return { ok: false, message: chrome.i18n.getMessage("errorMergeRequiresTwoResources") };
    }
    const ordered = sortResourcesForOnlineMerge(resources);
    try {
      const result = await options.sendDesktopRequest({
        type: "create_task",
        source: "resource_merge",
        title: mergeOutputTitle(ordered),
        payload: {
          resources: ordered.map((resource) => ({
            url: resource.url,
            filename: taskNameForResource(resource),
            mime: resource.mime,
            size: resource.size,
            headers: resource.requestHeaders,
            pageTitle: resource.pageTitle,
            supportsRange: resource.supportsRange
          }))
        }
      });
      if (result.ok) {
        ordered.forEach((resource) => cache.setSent(resource.id));
        return { ...result, message: result.message || chrome.i18n.getMessage("mergeTaskSentToDesktop") };
      }
      return result;
    } catch (error) {
      return { ok: false, message: error instanceof Error ? error.message : chrome.i18n.getMessage("errorMergeFailed") };
    }
  }
  async function mergeResources(resourceIds) {
    const ids = [...new Set(resourceIds.filter(Boolean))];
    const resources = ids.map((resourceId) => cache.resourceById(resourceId) ?? null).filter((resource) => resource != null);
    if (!canUseOnlineMergeSelection(resources)) {
      return { ok: false, message: chrome.i18n.getMessage("errorResourcesNotMergeable") };
    }
    return sendMergeResources(resources);
  }
  function buildPopupStateData(resolvedTabId, activeTab) {
    const canCaptureCurrentTab = Boolean(activeTab?.url && isCapturableUrl(activeTab.url));
    let resourceState = "ready";
    let resourceStateMessage = chrome.i18n.getMessage("waitingForResourceCapture");
    if (!loadedFromStorage) {
      resourceState = "restoring";
      resourceStateMessage = chrome.i18n.getMessage("restoringCatCatchResources");
    } else if (!canCaptureCurrentTab) {
      resourceState = "unavailable";
      resourceStateMessage = chrome.i18n.getMessage("tabNotSupportResourceBridge");
    }
    return {
      resourceState,
      resourceStateMessage,
      currentResources: resolvedTabId == null ? [] : cache.resourcesForTab(resolvedTabId),
      otherResources: cache.otherResources(resolvedTabId),
      activePageDomain: domainFromUrl(activeTab?.url ?? "")
    };
  }
  function onTabRemoved(tabId) {
    cache.clearTab(tabId);
    if (lastActiveTabId === tabId) {
      void setLastActiveTab(null);
    }
  }
  function onNavigationCommitted(details) {
    if (details.tabId <= 0 || details.frameId !== 0) {
      return;
    }
    cache.clearTab(details.tabId);
  }
  function onRequestHeaders(details) {
    const headers = selectAllowedHeaders(Object.fromEntries((details.requestHeaders ?? []).map((header) => [header.name ?? "", header.value ?? ""])));
    const supportsRange = (details.requestHeaders ?? []).some((header) => header.name?.toLowerCase() === "range" && String(header.value ?? "").toLowerCase().startsWith("bytes="));
    cache.setHeaderSnapshot(details.url, headers, details.tabId > 0 ? details.tabId : lastActiveTabId, supportsRange);
  }
  return {
    buildPopupStateData,
    captureNetworkResource,
    capturePageResource,
    captureRequestResource,
    downloadPageMedia,
    flushState,
    enrichResource: (urls, meta) => cache.enrichResource(urls, meta),
    enrichTabPoster: (tabId, posterUrl) => cache.enrichTabPoster(tabId, posterUrl),
    headersForPage: (pageUrl) => cache.headersForPage(pageUrl),
    routeBrowserDownload,
    onNavigationCommitted,
    onRequestHeaders,
    onTabRemoved,
    loadPersistentState,
    refreshActiveTabFromBrowser,
    currentTabId,
    mergeResources,
    sendResource,
    setLastActiveTab
  };
}

// src/shared/browser.ts
var REQUEST_HEADERS = "requestHeaders";
var EXTRA_HEADERS = "extraHeaders";
var cachedBrowserTarget = null;
function extensionBrowserTarget() {
  if (cachedBrowserTarget) {
    return cachedBrowserTarget;
  }
  try {
    const runtimeUrl = chrome.runtime.getURL("/");
    if (runtimeUrl.startsWith("moz-extension://")) {
      cachedBrowserTarget = "firefox";
      return cachedBrowserTarget;
    }
  } catch {
  }
  cachedBrowserTarget = "chromium";
  return cachedBrowserTarget;
}
function onSendHeadersExtraInfoSpec() {
  return extensionBrowserTarget() === "firefox" ? [REQUEST_HEADERS] : [REQUEST_HEADERS, EXTRA_HEADERS];
}
function supportsDownloadDeterminingFilename() {
  return Boolean(chrome.downloads?.onDeterminingFilename?.addListener);
}

// src/background/icon-progress.ts
var baseIcon16 = null;
var baseIcon32 = null;
var indeterminateAngle = 0;
var indeterminateTimer = null;
var isShowingProgress = false;
var BRAND_COLOR = "#0078d4";
var TRACK_COLOR = "rgba(0, 0, 0, 0.12)";
var ARC_LENGTH = Math.PI / 2;
var FRAME_INTERVAL_MS = 80;
var ANGLE_STEP = Math.PI / 12;
async function loadBaseIcons() {
  try {
    const response = await fetch(chrome.runtime.getURL("icon48.png"));
    const blob = await response.blob();
    baseIcon16 = await createImageBitmap(blob, { resizeWidth: 16, resizeHeight: 16 });
    baseIcon32 = await createImageBitmap(blob, { resizeWidth: 32, resizeHeight: 32 });
  } catch {
  }
}
function drawIcon(size, icon, arc) {
  const canvas = new OffscreenCanvas(size, size);
  const ctx = canvas.getContext("2d");
  ctx.drawImage(icon, 0, 0, size, size);
  const lineWidth = size >= 32 ? 2 : 1.5;
  const center = size / 2;
  const radius = center - lineWidth / 2 - 0.5;
  ctx.lineWidth = lineWidth;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.arc(center, center, radius, 0, Math.PI * 2);
  ctx.strokeStyle = TRACK_COLOR;
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(center, center, radius, arc.start, arc.end);
  ctx.strokeStyle = BRAND_COLOR;
  ctx.stroke();
  return ctx.getImageData(0, 0, size, size);
}
function pushIcon(arc) {
  if (!baseIcon16 || !baseIcon32) {
    return;
  }
  chrome.action.setIcon({
    imageData: {
      16: drawIcon(16, baseIcon16, arc),
      32: drawIcon(32, baseIcon32, arc)
    }
  });
}
function resetIcon() {
  if (!isShowingProgress) {
    return;
  }
  stopIndeterminate();
  isShowingProgress = false;
  chrome.action.setIcon({
    path: { 16: "icon16.png", 32: "icon32.png", 48: "icon48.png", 128: "icon128.png" }
  });
}
function startIndeterminate() {
  if (indeterminateTimer !== null) {
    return;
  }
  indeterminateTimer = self.setInterval(() => {
    indeterminateAngle = (indeterminateAngle + ANGLE_STEP) % (Math.PI * 2);
    pushIcon({ start: indeterminateAngle, end: indeterminateAngle + ARC_LENGTH });
  }, FRAME_INTERVAL_MS);
}
function stopIndeterminate() {
  if (indeterminateTimer !== null) {
    self.clearInterval(indeterminateTimer);
    indeterminateTimer = null;
  }
  indeterminateAngle = 0;
}
function updateIconForTasks(tasks) {
  const running = tasks.filter((t) => t.status === "running");
  if (running.length === 0) {
    resetIcon();
    return;
  }
  isShowingProgress = true;
  let knownTotal = 0;
  let knownReceived = 0;
  for (const t of running) {
    if (t.fileSize > 0) {
      knownTotal += t.fileSize;
      knownReceived += t.receivedBytes;
    }
  }
  if (knownTotal > 0) {
    stopIndeterminate();
    const progress = Math.min(knownReceived / knownTotal, 1);
    const startAngle = -Math.PI / 2;
    pushIcon({ start: startAngle, end: startAngle + progress * Math.PI * 2 });
  } else {
    startIndeterminate();
  }
}

// src/background/task-queue.ts
var SESSION_KEY = "pendingTasks";
async function readQueue() {
  const data = await chrome.storage.session.get(SESSION_KEY);
  const items = data[SESSION_KEY];
  return Array.isArray(items) ? items : [];
}
async function writeQueue(items) {
  await chrome.storage.session.set({ [SESSION_KEY]: items });
}
async function enqueue(payload) {
  const queue = await readQueue();
  queue.push(payload);
  await writeQueue(queue);
  return queue.length;
}
async function flush(sendFn) {
  const queue = await readQueue();
  if (queue.length === 0) {
    return 0;
  }
  const failed = [];
  let sent = 0;
  for (const payload of queue) {
    try {
      await sendFn(payload);
      sent += 1;
    } catch {
      failed.push(payload);
    }
  }
  await writeQueue(failed);
  return sent;
}
async function pendingCount() {
  const queue = await readQueue();
  return queue.length;
}

// src/background.ts
function parseExtensions(raw) {
  const result = /* @__PURE__ */ new Set();
  for (const part of raw.split(",")) {
    const ext = part.trim().replace(/^\./, "").toLowerCase();
    if (ext) {
      result.add(ext);
    }
  }
  return result;
}
async function flushQueue() {
  const sent = await flush((payload) => desktopBridge.sendRequest(payload));
  if (sent > 0) {
    await openActionPopup();
  }
}
async function sendTaskOrEnqueue(payload, timeoutMs) {
  if (desktopBridge.isReady()) {
    try {
      return await desktopBridge.sendRequest(payload, timeoutMs);
    } catch (error) {
      if (desktopBridge.isReady()) {
        throw error;
      }
    }
  }
  await enqueue(payload);
  return { ok: true, message: chrome.i18n.getMessage("taskQueued") };
}
var openWhenDoneIds = /* @__PURE__ */ new Set();
function onTaskSnapshotChanged(tasks) {
  updateIconForTasks(tasks);
  for (const task of tasks) {
    if (task.status === "completed" && openWhenDoneIds.has(task.taskId)) {
      openWhenDoneIds.delete(task.taskId);
      void desktopBridge.sendRequest({
        type: "task_action",
        taskId: task.taskId,
        action: "open_file"
      });
    }
  }
}
var desktopBridge = createDesktopBridge({
  onTaskSnapshotChanged,
  onConnected: () => void flushQueue()
});
var resourceBridge = createResourceBridge({
  sendDesktopRequest: (payload) => sendTaskOrEnqueue(payload)
});
var featureBridge = createFeatureBridge();
var mediaBridge = createMediaBridge();
var shouldTakeDownloads = true;
var isMediaButtonEnabled = true;
var minTakeSizeKB = 0;
var shouldTakeUnknownSize = true;
var skipExtensions = /* @__PURE__ */ new Set();
function imageFilename(url, alt) {
  try {
    const pathname = new URL(url).pathname;
    const basename = decodeURIComponent(pathname.split("/").pop() || "");
    if (basename && /\.\w{2,5}$/.test(basename)) {
      return basename.slice(0, 160);
    }
  } catch {
  }
  const safe = (alt || "image").replace(/[<>:"/\\|?*\x00-\x1f]+/g, " ").trim().slice(0, 120);
  return safe || "image";
}
async function injectMediaButton(tabId) {
  if (!isMediaButtonEnabled) {
    return;
  }
  const tab = await findTab(tabId);
  if (!tab?.url || !/^https?:/i.test(tab.url)) {
    return;
  }
  try {
    await chrome.scripting.executeScript({
      files: ["page-media-overlay.js"],
      injectImmediately: false,
      target: { tabId, allFrames: true }
    });
  } catch {
  }
}
async function setMediaButtonEnabled(enabled) {
  isMediaButtonEnabled = enabled;
  await chrome.storage.local.set({ [IS_MEDIA_BUTTON_ENABLED_KEY]: enabled });
  const tabs = await queryTabs({});
  for (const tab of tabs) {
    if (!tab.id || !tab.url || !/^https?:/i.test(tab.url)) {
      continue;
    }
    chrome.tabs.sendMessage(tab.id, {
      type: "media_button_set_enabled",
      enabled
    }, () => {
      const lastError = chrome.runtime.lastError;
      if (enabled && lastError && tab.id) {
        void injectMediaButton(tab.id);
      }
    });
  }
}
function buildTaskCounters(tasks) {
  return {
    total: tasks.length,
    active: tasks.filter((task) => task.status !== "completed").length,
    completed: tasks.filter((task) => task.status === "completed").length
  };
}
async function buildPopupState(options = {}) {
  const activeTabId = await resourceBridge.currentTabId(options.preferredTabId ?? null);
  const activeTab = activeTabId != null ? await findTab(activeTabId) : null;
  const desktopState = desktopBridge.buildSnapshot();
  const resourceState = resourceBridge.buildPopupStateData(activeTabId, activeTab);
  const mediaPanelState = await mediaBridge.buildPanelState(
    options.currentView === "advanced" ? activeTabId : null
  );
  return {
    connectionState: desktopState.connectionState,
    connectionMessage: desktopState.connectionMessage,
    desktopVersion: desktopState.desktopVersion,
    token: desktopState.token,
    serverUrl: desktopState.serverUrl,
    shouldTakeDownloads,
    isMediaButtonEnabled,
    tasks: desktopState.tasks.map((t) => ({ ...t, shouldOpenWhenDone: openWhenDoneIds.has(t.taskId) })),
    taskCounters: buildTaskCounters(desktopState.tasks),
    tabId: activeTabId,
    featureStates: featureBridge.createFeatureStateMap(activeTabId),
    mediaItems: mediaPanelState.mediaItems,
    mediaPlaybackState: mediaPanelState.playbackState,
    pendingTaskCount: await pendingCount(),
    ...resourceState
  };
}
async function setupBackground() {
  const localState = await loadLocalState({
    [SHOULD_TAKE_DOWNLOADS_KEY]: true,
    [IS_MEDIA_BUTTON_ENABLED_KEY]: true,
    [MIN_TAKE_SIZE_KB_KEY]: 0,
    [SHOULD_TAKE_UNKNOWN_SIZE_KEY]: true,
    [SKIP_EXTENSIONS_KEY]: ""
  });
  shouldTakeDownloads = Boolean(localState[SHOULD_TAKE_DOWNLOADS_KEY] ?? true);
  isMediaButtonEnabled = Boolean(localState[IS_MEDIA_BUTTON_ENABLED_KEY] ?? true);
  minTakeSizeKB = Number(localState[MIN_TAKE_SIZE_KB_KEY]) || 0;
  shouldTakeUnknownSize = Boolean(localState[SHOULD_TAKE_UNKNOWN_SIZE_KEY] ?? true);
  skipExtensions = parseExtensions(String(localState[SKIP_EXTENSIONS_KEY] ?? ""));
  try {
    const selfInfo = await chrome.management.getSelf();
    desktopBridge.setInstallType(selfInfo.installType);
  } catch {
    desktopBridge.setInstallType("normal");
  }
  await loadBaseIcons();
  await desktopBridge.loadPersistentState();
  await resourceBridge.loadPersistentState();
  await featureBridge.loadPersistentState();
  const activeTabId = await resourceBridge.currentTabId();
  if (activeTabId != null) {
    void injectMediaButton(activeTabId);
  }
  if (desktopBridge.buildSnapshot().token) {
    void desktopBridge.connect();
  } else {
    void desktopBridge.requestPairing().catch(() => {
    });
  }
  desktopBridge.setupReconnectAlarm();
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "gd-download",
    title: chrome.i18n.getMessage("downloadWithGhostDownloader"),
    contexts: ["link", "image", "video", "audio"]
  });
  chrome.contextMenus.create({
    id: "gd-save-as",
    title: chrome.i18n.getMessage("saveAsWithGhostDownloader"),
    contexts: ["link", "image", "video", "audio"]
  });
});
chrome.contextMenus.onClicked.addListener((info) => {
  const url = info.linkUrl || info.srcUrl;
  if (!url) {
    return;
  }
  const draft = info.menuItemId === "gd-save-as";
  const headers = resourceBridge.headersForPage(info.pageUrl ?? "");
  if (!headers.referer && info.pageUrl) {
    headers.referer = info.pageUrl;
  }
  void sendTaskOrEnqueue({
    type: "create_task",
    source: "download",
    draft,
    title: "",
    payload: { url, headers, filename: "", size: 0, supportsRange: false }
  }).then((result) => {
    if (result.ok) {
      void openActionPopup();
    }
  });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  desktopBridge.onReconnectAlarm(alarm);
});
chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "HeartBeat") {
    port.postMessage("HeartBeat");
  }
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local") {
    return;
  }
  desktopBridge.onLocalStorageChanged(changes);
  if (changes[SHOULD_TAKE_DOWNLOADS_KEY]) {
    shouldTakeDownloads = Boolean(changes[SHOULD_TAKE_DOWNLOADS_KEY].newValue ?? true);
  }
  if (changes[IS_MEDIA_BUTTON_ENABLED_KEY]) {
    isMediaButtonEnabled = Boolean(changes[IS_MEDIA_BUTTON_ENABLED_KEY].newValue ?? true);
  }
  if (changes[MIN_TAKE_SIZE_KB_KEY]) {
    minTakeSizeKB = Number(changes[MIN_TAKE_SIZE_KB_KEY].newValue) || 0;
  }
  if (changes[SHOULD_TAKE_UNKNOWN_SIZE_KEY]) {
    shouldTakeUnknownSize = Boolean(changes[SHOULD_TAKE_UNKNOWN_SIZE_KEY].newValue ?? true);
  }
  if (changes[SKIP_EXTENSIONS_KEY]) {
    skipExtensions = parseExtensions(String(changes[SKIP_EXTENSIONS_KEY].newValue ?? ""));
  }
});
chrome.tabs.onActivated.addListener((activeInfo) => {
  void resourceBridge.setLastActiveTab(activeInfo.tabId);
  void injectMediaButton(activeInfo.tabId);
});
chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    return;
  }
  void resourceBridge.refreshActiveTabFromBrowser().then((tabId) => {
    if (tabId != null) {
      void injectMediaButton(tabId);
    }
  });
});
chrome.tabs.onRemoved.addListener((tabId) => {
  resourceBridge.onTabRemoved(tabId);
  mediaBridge.onTabRemoved(tabId);
  featureBridge.onTabRemoved(tabId);
});
chrome.webNavigation.onCommitted.addListener((details) => {
  resourceBridge.onNavigationCommitted(details);
  featureBridge.onNavigationCommitted(details);
});
chrome.webRequest.onSendHeaders.addListener(
  (details) => {
    resourceBridge.onRequestHeaders(details);
    void resourceBridge.captureRequestResource(details);
  },
  { urls: ["<all_urls>"] },
  onSendHeadersExtraInfoSpec()
);
chrome.webRequest.onResponseStarted.addListener(
  (details) => {
    void resourceBridge.captureNetworkResource(details);
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);
var bypassNextDownload = false;
var bypassTimer = 0;
var autoLaunchPending = false;
async function takeBrowserDownload(downloadItem, options = {}) {
  if (bypassNextDownload) {
    bypassNextDownload = false;
    clearTimeout(bypassTimer);
    return;
  }
  const finalUrl = downloadItem.finalUrl || downloadItem.url;
  if (!shouldTakeDownloads || !/^https?:/i.test(finalUrl)) {
    return;
  }
  if (skipExtensions.size > 0) {
    const filename = downloadItem.filename || new URL(finalUrl).pathname.split("/").pop() || "";
    const ext = filename.includes(".") ? filename.split(".").pop().toLowerCase() : "";
    if (ext && skipExtensions.has(ext)) {
      return;
    }
  }
  if (minTakeSizeKB > 0) {
    const totalBytes = downloadItem.totalBytes ?? -1;
    if (totalBytes < 0 && !shouldTakeUnknownSize) {
      return;
    }
    if (totalBytes >= 0 && totalBytes < minTakeSizeKB * 1024) {
      return;
    }
  }
  const wasReady = desktopBridge.isReady();
  try {
    await cancelDownload(downloadItem.id);
    if (options.eraseFromHistory) {
      await eraseDownloadFromHistory(downloadItem.id);
    }
  } catch {
  }
  if (!wasReady) {
    autoLaunchPending = true;
  }
  await resourceBridge.routeBrowserDownload(downloadItem);
}
function sendReply(sendResponse, response) {
  void response.then(sendResponse);
  return true;
}
if (supportsDownloadDeterminingFilename()) {
  chrome.downloads.onDeterminingFilename.addListener((downloadItem, suggest) => {
    suggest();
    void takeBrowserDownload(downloadItem);
  });
} else if (chrome.downloads.onCreated?.addListener) {
  chrome.downloads.onCreated.addListener((downloadItem) => {
    void takeBrowserDownload(downloadItem, { eraseFromHistory: true });
  });
}
async function runPopupCommand(command) {
  switch (command.type) {
    case "popup_get_state":
      return buildPopupState({
        preferredTabId: typeof command.tabId === "number" ? command.tabId : null,
        currentView: command.view
      });
    case "popup_set_token":
      await desktopBridge.setToken(command.token.trim());
      return buildPopupState({ currentView: command.view });
    case "popup_set_server_url":
      await desktopBridge.setServerUrl(command.serverUrl);
      return buildPopupState({ currentView: command.view });
    case "popup_refresh_connection":
      await desktopBridge.connect(true);
      return buildPopupState({ currentView: command.view });
    case "popup_set_take_downloads":
      shouldTakeDownloads = command.enabled;
      await chrome.storage.local.set({ [SHOULD_TAKE_DOWNLOADS_KEY]: shouldTakeDownloads });
      return buildPopupState({ currentView: command.view });
    case "popup_set_media_button":
      await setMediaButtonEnabled(command.enabled);
      return buildPopupState({ currentView: command.view });
    case "popup_set_media_index":
      await mediaBridge.setMediaIndex(command.tabId, command.index);
      return buildPopupState({ currentView: "advanced" });
    case "popup_request_pairing":
      void desktopBridge.requestPairing().catch(() => {
      });
      return { ok: true, message: chrome.i18n.getMessage("confirmPairing") };
    case "popup_task_action":
      if (command.action === "open_when_done") {
        if (openWhenDoneIds.has(command.taskId)) {
          openWhenDoneIds.delete(command.taskId);
        } else {
          openWhenDoneIds.add(command.taskId);
        }
        return { ok: true };
      }
      try {
        return await desktopBridge.sendRequest({
          type: "task_action",
          taskId: command.taskId,
          action: command.action
        });
      } catch (error) {
        return { ok: false, message: error instanceof Error ? error.message : chrome.i18n.getMessage("errorTaskActionFailed") };
      }
    case "popup_send_resource":
      return resourceBridge.sendResource(command.resourceId);
    case "popup_merge_resources":
      return resourceBridge.mergeResources(command.resourceIds);
    case "popup_toggle_feature":
      try {
        const infoMessage = await featureBridge.toggleFeature(command.feature, command.tabId);
        return { ok: true, message: infoMessage };
      } catch (error) {
        return { ok: false, message: error instanceof Error ? error.message : chrome.i18n.getMessage("errorFeatureToggleFailed") };
      }
    case "popup_media_action":
      try {
        const playbackState = await mediaBridge.runAction(command.action, command.value);
        return { ok: true, message: "", playbackState };
      } catch (error) {
        return { ok: false, message: error instanceof Error ? error.message : chrome.i18n.getMessage("errorMediaActionFailed") };
      }
    case "popup_send_images": {
      let count = 0;
      for (const image of command.images) {
        const filename = imageFilename(image.src, image.alt);
        await sendTaskOrEnqueue({
          type: "create_task",
          source: "download",
          title: filename,
          payload: {
            url: image.src,
            headers: { referer: command.pageUrl },
            filename,
            size: 0,
            supportsRange: false
          }
        });
        count += 1;
      }
      return { ok: true, message: chrome.i18n.getMessage("imagesProcessed", [String(count)]) };
    }
    default:
      return unknownPopupCommand(command);
  }
}
function unknownPopupCommand(command) {
  return { ok: false, message: chrome.i18n.getMessage("errorUnknownCommand", [String(command.type ?? "")]) };
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message !== "object") {
    return;
  }
  if (message.Message === "addMedia" && typeof message.url === "string") {
    void resourceBridge.capturePageResource(sender, {
      url: message.url,
      href: message.href,
      mime: message.mime,
      ext: message.extraExt,
      requestHeaders: message.requestHeaders
    });
    sendResponse("ok");
    return true;
  }
  if (typeof message.type !== "string") {
    return;
  }
  if (message.type === "bridge_page_command") {
    void featureBridge.onBridgeScriptCommand(message.payload, sender);
    sendResponse({ ok: true });
    return true;
  }
  if (message.type === "page_download_media") {
    return sendReply(sendResponse, resourceBridge.downloadPageMedia(sender, {
      selection: message.selection,
      href: String(message.href ?? ""),
      title: String(message.title ?? "")
    }));
  }
  if (message.type === "media_metadata" && Array.isArray(message.urls)) {
    const meta = {
      duration: message.duration,
      videoWidth: message.videoWidth,
      videoHeight: message.videoHeight,
      posterUrl: message.posterUrl
    };
    resourceBridge.enrichResource(message.urls, meta);
    if (sender.tab?.id && meta.posterUrl) {
      resourceBridge.enrichTabPoster(sender.tab.id, meta.posterUrl);
    }
    return;
  }
  if (message.type === "page_poster" && message.posterUrl && sender.tab?.id) {
    resourceBridge.enrichTabPoster(sender.tab.id, String(message.posterUrl));
    return;
  }
  if (message.type === "bypass_next_download") {
    bypassNextDownload = true;
    clearTimeout(bypassTimer);
    bypassTimer = self.setTimeout(() => {
      bypassNextDownload = false;
    }, 3e3);
    return;
  }
  if (message.type === "popup_mounted") {
    const shouldLaunch = autoLaunchPending;
    autoLaunchPending = false;
    sendResponse({ autoLaunch: shouldLaunch });
    return;
  }
  if (message.type === "page_media_button_state") {
    sendResponse({ enabled: isMediaButtonEnabled });
    return;
  }
  if (message.type.startsWith("popup_")) {
    if (!sender.url?.startsWith("chrome-extension://") && !sender.url?.startsWith("moz-extension://")) {
      return;
    }
    return sendReply(sendResponse, runPopupCommand(message));
  }
});
chrome.runtime.onSuspend.addListener(() => {
  void resourceBridge.flushState();
});
await setupBackground();
