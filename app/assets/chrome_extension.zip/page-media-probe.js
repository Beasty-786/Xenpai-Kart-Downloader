"use strict";
(() => {
  // src/page-media/attribution/attribution-signal.ts
  var MEDIA_SIGNAL_KEY = "__gdMediaSignal";
  function postMediaSignal(signal) {
    try {
      window.postMessage({ [MEDIA_SIGNAL_KEY]: true, ...signal }, "*");
    } catch {
    }
  }

  // src/page-media/attribution/mse-probe.ts
  (function installGhostDownloaderMseAttribution() {
    if (window.__gdMseAttributionInstalled) {
      return;
    }
    window.__gdMseAttributionInstalled = true;
    const mediaSourceIdByInstance = /* @__PURE__ */ new WeakMap();
    let mediaSourceCounter = 0;
    function mediaSourceId(mediaSource) {
      let id = mediaSourceIdByInstance.get(mediaSource);
      if (id == null) {
        mediaSourceCounter += 1;
        id = `ms-${mediaSourceCounter}`;
        mediaSourceIdByInstance.set(mediaSource, id);
      }
      return id;
    }
    if (typeof window.URL?.createObjectURL === "function" && typeof window.MediaSource !== "undefined") {
      const originalCreateObjectUrl = window.URL.createObjectURL;
      window.URL.createObjectURL = function patchedCreateObjectURL(source) {
        const url = originalCreateObjectUrl(source);
        if (source instanceof MediaSource) {
          postMediaSignal({ kind: "mse_objecturl", mediaSourceId: mediaSourceId(source), objectUrl: url });
        }
        return url;
      };
    }
    if (typeof window.MediaSource !== "undefined") {
      const originalAddSourceBuffer = MediaSource.prototype.addSourceBuffer;
      MediaSource.prototype.addSourceBuffer = function patchedAddSourceBuffer(mimeType) {
        const sourceBuffer = originalAddSourceBuffer.call(this, mimeType);
        const sourceId = mediaSourceId(this);
        postMediaSignal({ kind: "mse_source_buffer_added", mediaSourceId: sourceId, mimeType });
        try {
          const originalAppendBuffer = sourceBuffer.appendBuffer;
          sourceBuffer.appendBuffer = function patchedAppendBuffer(data) {
            postMediaSignal({ kind: "mse_buffer_appended", mediaSourceId: sourceId, mimeType });
            return originalAppendBuffer.call(this, data);
          };
        } catch {
        }
        return sourceBuffer;
      };
    }
    if (typeof window.fetch === "function") {
      const originalFetch = window.fetch;
      window.fetch = function patchedFetch(input, init) {
        const url = typeof input === "string" ? input : input instanceof Request ? input.url : String(input ?? "");
        const promise = originalFetch(input, init);
        promise.then((response) => {
          try {
            postMediaSignal({
              kind: "request_completed",
              url: response?.url || url,
              contentType: response?.headers?.get?.("content-type") ?? ""
            });
          } catch {
          }
        }).catch(() => {
        });
        return promise;
      };
    }
    try {
      const originalOpen = XMLHttpRequest.prototype.open;
      const originalSend = XMLHttpRequest.prototype.send;
      XMLHttpRequest.prototype.open = function patchedOpen(method, url, ...rest) {
        this.__gdUrl = String(url);
        return originalOpen.apply(this, [method, url, ...rest]);
      };
      XMLHttpRequest.prototype.send = function patchedSend(body) {
        const xhr = this;
        const url = xhr.__gdUrl || "";
        xhr.addEventListener("loadend", () => {
          try {
            postMediaSignal({
              kind: "request_completed",
              url,
              contentType: xhr.getResponseHeader?.("content-type") ?? ""
            });
          } catch {
          }
        });
        return originalSend.call(this, body);
      };
    } catch {
    }
  })();
})();
