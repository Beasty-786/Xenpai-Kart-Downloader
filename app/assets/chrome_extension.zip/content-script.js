"use strict";
(() => {
  // src/cat-catch-bridge.ts
  function installCatCatchBridge() {
    window.addEventListener("message", (event) => {
      const payload = event.data;
      if (!payload || typeof payload !== "object" || payload.action !== "catCatchToBackground") {
        return;
      }
      chrome.runtime.sendMessage({
        type: "bridge_page_command",
        payload
      });
    });
  }

  // src/shared/cat-catch.ts
  var CAT_CATCH_HLS_TYPES = /* @__PURE__ */ new Set([
    "application/vnd.apple.mpegurl",
    "application/x-mpegurl",
    "application/mpegurl",
    "application/octet-stream-m3u8"
  ]);
  var CAT_CATCH_MPD_TYPES = /* @__PURE__ */ new Set(["application/dash+xml"]);
  var CAT_CATCH_VIDEO_EXTENSIONS = /* @__PURE__ */ new Set([
    "3gp",
    "asf",
    "avi",
    "divx",
    "f4v",
    "flv",
    "hlv",
    "m4s",
    "mkv",
    "mov",
    "mp4",
    "mpeg",
    "mpeg4",
    "movie",
    "ogv",
    "ts",
    "vid",
    "webm",
    "wmv"
  ]);
  var CAT_CATCH_AUDIO_EXTENSIONS = /* @__PURE__ */ new Set([
    "aac",
    "acc",
    "flac",
    "m4s",
    "m4a",
    "mp3",
    "ogg",
    "opus",
    "wav",
    "weba",
    "wma"
  ]);
  var CAT_CATCH_MEDIA_EXTENSIONS = /* @__PURE__ */ new Set([
    ...CAT_CATCH_VIDEO_EXTENSIONS,
    ...CAT_CATCH_AUDIO_EXTENSIONS,
    "m3u",
    "m3u8",
    "mpd"
  ]);
  function isCatCatchM3u8(extension, mime = "") {
    const type = String(mime || "").toLowerCase();
    return extension === "m3u8" || extension === "m3u" || CAT_CATCH_HLS_TYPES.has(type) || type.endsWith("/vnd.apple.mpegurl") || type.endsWith("/x-mpegurl") || type.endsWith("/mpegurl") || type.endsWith("/octet-stream-m3u8");
  }
  function isCatCatchMpd(extension, mime = "") {
    return extension === "mpd" || CAT_CATCH_MPD_TYPES.has(String(mime || "").toLowerCase());
  }
  function isCatCatchMedia(extension, mime = "") {
    const type = mime.toLowerCase();
    return CAT_CATCH_MEDIA_EXTENSIONS.has(extension) || type.startsWith("video/") || type.startsWith("audio/") || isCatCatchM3u8(extension, type) || isCatCatchMpd(extension, type);
  }

  // src/shared/utils.ts
  function mimeFromUrl(value) {
    try {
      const mime = new URL(value).searchParams.get("mime_type")?.replace(/_/g, "/").toLowerCase() ?? "";
      return isCatCatchMedia("", mime) ? mime : "";
    } catch {
      return "";
    }
  }
  function filenameFromUrl(value) {
    try {
      const url = new URL(value);
      return decodeURIComponent(url.pathname.split("/").pop() || "");
    } catch {
      return "";
    }
  }
  function fileExtension(name) {
    const dotIndex = name.lastIndexOf(".");
    return dotIndex < 0 ? "" : name.slice(dotIndex + 1).toLowerCase();
  }
  function dashTrackRoleOf(filename, url) {
    const name = filename || filenameFromUrl(url);
    const lowered = `${name} ${url}`.toLowerCase();
    if (/(^|[-_.\\/])(video)([-_.\\/]|$)/i.test(lowered)) {
      return "video";
    }
    if (/(^|[-_.\\/])(audio)([-_.\\/]|$)/i.test(lowered)) {
      return "audio";
    }
    const match = lowered.match(/-(\d{5,6})(?=\.m4s(?:$|[?#]))/i) ?? lowered.match(/\/(\d{5,6})(?=\.m4s(?:$|[?#]))/i);
    const trackId = Number(match?.[1] ?? 0);
    if (!Number.isFinite(trackId) || trackId <= 0) {
      return "";
    }
    if (trackId >= 1e5) {
      return "video";
    }
    if (trackId >= 3e4 && trackId < 4e4) {
      return "audio";
    }
    return "";
  }

  // src/page-media/resolution/url-classify.ts
  function hostEndsWith(url, suffix) {
    try {
      return new URL(url).hostname.endsWith(suffix);
    } catch {
      return false;
    }
  }
  var RANGE_PARAM_KEYS = ["bytestart", "byteend", "_nc_rmd"];
  function stripRangeParams(url) {
    try {
      const parsed = new URL(url);
      let modified = false;
      for (const key of RANGE_PARAM_KEYS) {
        if (parsed.searchParams.has(key)) {
          parsed.searchParams.delete(key);
          modified = true;
        }
      }
      return modified ? parsed.toString() : url;
    } catch {
      return url;
    }
  }
  function isStreamUrl(url, contentType) {
    const ext = fileExtension(filenameFromUrl(url));
    return isCatCatchM3u8(ext, contentType) || isCatCatchMpd(ext, contentType);
  }
  function isDashSegmentUrl(url) {
    if (url.includes("/media-audio-") || url.includes("/media-video-")) {
      return true;
    }
    return fileExtension(filenameFromUrl(url)) === "m4s";
  }
  function douyinKindOf(url) {
    if (url.includes("/media-audio-")) {
      return "audio";
    }
    if (url.includes("/media-video-")) {
      return "video";
    }
    if (hostEndsWith(url, "douyinvod.com") && url.includes("__vid=")) {
      return "muxed";
    }
    return "";
  }
  function isInstagramCdnUrl(url) {
    return hostEndsWith(url, "cdninstagram.com") || hostEndsWith(url, "fbcdn.net");
  }
  function parseEfg(url) {
    try {
      const efg = new URL(url).searchParams.get("efg");
      if (!efg) {
        return null;
      }
      return JSON.parse(atob(efg));
    } catch {
      return null;
    }
  }
  function instagramVencodeTag(url) {
    const efg = parseEfg(url);
    if (!efg || typeof efg !== "object") {
      return "";
    }
    const tag = efg.vencode_tag;
    return typeof tag === "string" ? tag : "";
  }
  function instagramAssetId(url) {
    const efg = parseEfg(url);
    if (!efg || typeof efg !== "object") {
      return "";
    }
    const id = efg.xpv_asset_id;
    if (typeof id === "string") {
      return id;
    }
    if (typeof id === "number") {
      return String(id);
    }
    return "";
  }
  function instagramKindOf(url) {
    const tag = instagramVencodeTag(url);
    if (!tag) {
      return "";
    }
    if (tag.includes("_audio")) {
      return "audio";
    }
    if (tag.includes("dash_")) {
      return "video";
    }
    return "";
  }
  function classifyTrackRole(url, contentType) {
    const douyin = douyinKindOf(url);
    if (douyin === "muxed") {
      return "muxed";
    }
    if (douyin === "video") {
      return "video";
    }
    if (douyin === "audio") {
      return "audio";
    }
    const mime = (contentType || mimeFromUrl(url) || "").toLowerCase();
    if (mime.includes("codecs")) {
      if (mime.startsWith("video/")) {
        return "video";
      }
      if (mime.startsWith("audio/")) {
        return "audio";
      }
    }
    if (mime.startsWith("video/") && !isDashSegmentUrl(url)) {
      return "video";
    }
    if (mime.startsWith("audio/")) {
      return "audio";
    }
    const ext = fileExtension(filenameFromUrl(url));
    if (ext === "m4s") {
      const dashRole = dashTrackRoleOf(filenameFromUrl(url), url);
      if (dashRole === "video" || dashRole === "audio") {
        return dashRole;
      }
      return "unknown";
    }
    if (isCatCatchMedia(ext, mime)) {
      return "muxed";
    }
    return "unknown";
  }

  // src/page-media/attribution/attribution-ledger.ts
  var AttributionLedger = class {
    entries = /* @__PURE__ */ new Map();
    // Locked entries never move. Provisional entries only move on a locked claim — late
    // tier-2/3 claims don't churn ownership.
    claim(url, sessionId, tier, attributedAt, locked) {
      const existing = this.entries.get(url);
      if (existing && existing.lockedByMse) {
        return { ownerId: existing.sessionId, moved: false };
      }
      if (existing && !locked) {
        return { ownerId: existing.sessionId, moved: false };
      }
      this.entries.set(url, { sessionId, attributedAt, tier, lockedByMse: locked });
      return {
        ownerId: sessionId,
        moved: existing != null && existing.sessionId !== sessionId
      };
    }
    lookup(url) {
      return this.entries.get(url) ?? null;
    }
    // idHintsForUrl is a callback so the ledger stays free of URL parsing.
    reclaimUrls(newSessionId, newIdHints, idHintsForUrl, now) {
      if (newIdHints.size === 0) {
        return { urls: [] };
      }
      const moved = [];
      for (const [url, entry] of this.entries) {
        if (entry.lockedByMse) {
          continue;
        }
        if (entry.sessionId === newSessionId) {
          continue;
        }
        const urlIdHints2 = idHintsForUrl(url);
        let intersects = false;
        for (const d of urlIdHints2) {
          if (newIdHints.has(d)) {
            intersects = true;
            break;
          }
        }
        if (!intersects) {
          continue;
        }
        this.entries.set(url, {
          sessionId: newSessionId,
          attributedAt: now,
          tier: "mse",
          lockedByMse: true
        });
        moved.push(url);
      }
      return { urls: moved };
    }
    // Pins URLs that were already correctly attributed before MSE bind.
    lockAllFor(sessionId) {
      for (const [url, entry] of this.entries) {
        if (entry.sessionId === sessionId && !entry.lockedByMse) {
          this.entries.set(url, { ...entry, lockedByMse: true, tier: "mse" });
        }
      }
    }
    release(sessionId) {
      const released = [];
      for (const [url, entry] of this.entries) {
        if (entry.sessionId === sessionId) {
          this.entries.delete(url);
          released.push(url);
        }
      }
      return released;
    }
    size() {
      return this.entries.size;
    }
  };

  // src/page-media/resolution/strategies/douyin.ts
  function selectDouyin(ctx, findUrlsByIdHint) {
    const post = postBindAttributedUrls(ctx.clicked).filter((r) => hostEndsWith(r.url, "douyinvod.com"));
    if (ctx.clicked.formKind === "muxed") {
      const muxed2 = newestMatching(post, (url) => douyinKindOf(url) === "muxed") ?? findByModalId(ctx, findUrlsByIdHint, "muxed");
      if (muxed2) {
        return { kind: "selection", selection: { kind: "single", url: muxed2, formKind: "muxed" } };
      }
      return { kind: "pending", reason: chrome.i18n.getMessage("waitingForDouyinMuxedUrl") };
    }
    if (ctx.clicked.formKind === "dash") {
      const video = newestMatching(post, (url) => douyinKindOf(url) === "video") ?? findByModalId(ctx, findUrlsByIdHint, "video");
      const audio = newestMatching(post, (url) => douyinKindOf(url) === "audio") ?? findByModalId(ctx, findUrlsByIdHint, "audio");
      if (video && audio) {
        return { kind: "selection", selection: { kind: "merge", video, audio } };
      }
      return { kind: "pending", reason: chrome.i18n.getMessage("waitingForDouyinSeparateTracks") };
    }
    if (post.length === 0) {
      const fromModalId = findByModalId(ctx, findUrlsByIdHint, "muxed");
      if (fromModalId) {
        return { kind: "selection", selection: { kind: "single", url: fromModalId, formKind: "unknown" } };
      }
      return { kind: "pending", reason: chrome.i18n.getMessage("waitingForVideoResource") };
    }
    const muxed = newestMatching(post, (url) => douyinKindOf(url) === "muxed");
    if (muxed) {
      return { kind: "selection", selection: { kind: "single", url: muxed, formKind: "unknown" } };
    }
    const pair = selectMergePair(post, douyinKindOf);
    if (pair) {
      return { kind: "selection", selection: { kind: "merge", video: pair.video, audio: pair.audio } };
    }
    return { kind: "refused", message: chrome.i18n.getMessage("errorCannotDetermineDouyinMediaForm") };
  }
  function findByModalId(ctx, findUrlsByIdHint, kind) {
    const modalId = ctx.pageUrl.searchParams.get("modal_id");
    if (!modalId || modalId.length < 4) {
      return void 0;
    }
    const matches = findUrlsByIdHint(`__vid=${modalId}`);
    return newestMatching(matches, (url) => douyinKindOf(url) === kind);
  }

  // src/page-media/resolution/strategies/generic.ts
  function selectGeneric(ctx) {
    const post = postBindAttributedUrls(ctx.clicked);
    const stream = newestMatching(post, isStreamUrl);
    if (stream) {
      return { kind: "selection", selection: { kind: "stream", url: stream } };
    }
    if (ctx.clicked.formKind === "muxed") {
      const muxed = newestMatching(post, (url) => !isDashSegmentUrl(url));
      if (muxed) {
        return { kind: "selection", selection: { kind: "single", url: stripRangeParams(muxed), formKind: "muxed" } };
      }
      return { kind: "pending", reason: chrome.i18n.getMessage("waitingForVideoResource") };
    }
    if (ctx.clicked.formKind === "dash") {
      const pair = selectMergePair(post, classifyTrackRole);
      if (pair) {
        return { kind: "selection", selection: { kind: "merge", video: stripRangeParams(pair.video), audio: stripRangeParams(pair.audio) } };
      }
      return { kind: "pending", reason: chrome.i18n.getMessage("waitingForSeparateTracks") };
    }
    if (post.length === 0) {
      return { kind: "pending", reason: chrome.i18n.getMessage("waitingForVideoResource") };
    }
    if (post.length === 1) {
      const only = post[0];
      if (isDashSegmentUrl(only.url)) {
        return { kind: "pending", reason: chrome.i18n.getMessage("waitingForSeparateTracks") };
      }
      return { kind: "selection", selection: { kind: "single", url: stripRangeParams(only.url), formKind: "unknown" } };
    }
    return { kind: "refused", message: chrome.i18n.getMessage("errorMultipleMediaFound") };
  }

  // src/page-media/resolution/strategies/instagram.ts
  function selectInstagram(ctx, findUrlsByIdHint) {
    const post = postBindAttributedUrls(ctx.clicked).filter((r) => isInstagramCdnUrl(r.url));
    if (ctx.clicked.formKind === "dash") {
      const pair2 = selectMergePair(post, instagramKindOf) ?? findPairByAssetId(post, findUrlsByIdHint);
      if (pair2) {
        return { kind: "selection", selection: { kind: "merge", video: stripRangeParams(pair2.video), audio: stripRangeParams(pair2.audio) } };
      }
      return { kind: "pending", reason: chrome.i18n.getMessage("waitingForInstagramSeparateTracks") };
    }
    if (post.length === 0) {
      return { kind: "pending", reason: chrome.i18n.getMessage("waitingForVideoResource") };
    }
    const pair = selectMergePair(post, instagramKindOf);
    if (pair) {
      return { kind: "selection", selection: { kind: "merge", video: stripRangeParams(pair.video), audio: stripRangeParams(pair.audio) } };
    }
    return { kind: "pending", reason: chrome.i18n.getMessage("waitingForInstagramSeparateTracks") };
  }
  function findPairByAssetId(post, findUrlsByIdHint) {
    let assetId = "";
    for (const entry of post) {
      assetId = instagramAssetId(entry.url);
      if (assetId) {
        break;
      }
    }
    if (!assetId) {
      return null;
    }
    const matches = findUrlsByIdHint(`xpv_asset_id=${assetId}`);
    const video = newestMatching(matches, (url) => instagramKindOf(url) === "video");
    const audio = newestMatching(matches, (url) => instagramKindOf(url) === "audio");
    return video && audio ? { video, audio } : null;
  }

  // src/page-media/resolution/strategies/x.ts
  var TWITTER_MEDIA_ID = /\/(?:amplify_video(?:_thumb)?|ext_tw_video|tweet_video)\/(\d+)\//i;
  function mediaIdOf(url) {
    return TWITTER_MEDIA_ID.exec(url)?.[1] ?? "";
  }
  function isMasterTwitterPlaylist(url) {
    try {
      const parts = new URL(url).pathname.split("/").filter(Boolean);
      const plIdx = parts.indexOf("pl");
      return plIdx !== -1 && plIdx === parts.length - 2;
    } catch {
      return false;
    }
  }
  function selectX(ctx) {
    const posterMediaId = mediaIdOf(ctx.hints.poster ?? "");
    const allStreams = postBindAttributedUrls(ctx.clicked).filter(
      (r) => hostEndsWith(r.url, "video.twimg.com") && isStreamUrl(r.url, r.contentType)
    );
    const candidates = posterMediaId ? allStreams.filter((r) => mediaIdOf(r.url) === posterMediaId) : allStreams;
    const pick = newestMatching(candidates, (url) => isMasterTwitterPlaylist(url));
    if (pick) {
      return { kind: "selection", selection: { kind: "stream", url: pick } };
    }
    return { kind: "pending", reason: chrome.i18n.getMessage("waitingForXMasterPlaylist") };
  }

  // src/page-media/resolution/strategies/youtube.ts
  function selectYouTube(ctx) {
    return { kind: "selection", selection: { kind: "external", pageUrl: ctx.pageUrl.href } };
  }

  // src/page-media/resolution/strategy.ts
  function selectMediaForPage(ctx, findUrlsByIdHint) {
    const host = ctx.pageUrl.hostname;
    if (host === "x.com" || host.endsWith(".x.com")) {
      return selectX(ctx);
    }
    if (host === "www.douyin.com" || host.endsWith(".douyin.com")) {
      return selectDouyin(ctx, findUrlsByIdHint);
    }
    if (host === "www.instagram.com" || host.endsWith(".instagram.com")) {
      return selectInstagram(ctx, findUrlsByIdHint);
    }
    if (host === "youtube.com" || host.endsWith(".youtube.com") || host === "youtu.be") {
      return selectYouTube(ctx);
    }
    return selectGeneric(ctx);
  }
  function postBindAttributedUrls(view) {
    if (view.lastBoundAt <= 0) {
      return view.attributedUrls;
    }
    return view.attributedUrls.filter((r) => r.capturedAt >= view.lastBoundAt);
  }
  function newestBy(items, key) {
    if (items.length === 0) {
      return void 0;
    }
    let best = items[0];
    let bestKey = key(best);
    for (let i = 1; i < items.length; i += 1) {
      const k = key(items[i]);
      if (k > bestKey) {
        best = items[i];
        bestKey = k;
      }
    }
    return best;
  }
  function newestMatching(urls, predicate) {
    return newestBy(urls.filter((entry) => predicate(entry.url, entry.contentType)), (entry) => entry.capturedAt)?.url;
  }
  function selectMergePair(urls, classify) {
    const video = newestMatching(urls, (url, contentType) => classify(url, contentType) === "video");
    const audio = newestMatching(urls, (url, contentType) => classify(url, contentType) === "audio");
    return video && audio ? { video, audio } : null;
  }

  // src/page-media/attribution/attribution-signal.ts
  var MEDIA_SIGNAL_KEY = "__gdMediaSignal";
  function postMediaSignal(signal) {
    try {
      window.postMessage({ [MEDIA_SIGNAL_KEY]: true, ...signal }, "*");
    } catch {
    }
  }
  function isMediaSignal(data) {
    return typeof data === "object" && data !== null && data[MEDIA_SIGNAL_KEY] === true;
  }

  // src/page-media/attribution/attribution.ts
  var LOG_PREFIX = "[GD Media]";
  var VIDEO_ID_QUERY_KEYS = ["__vid", "v", "modal_id", "video_id", "id", "bvid", "aid"];
  var WAIT_FOR_TIMEOUT_MS = 8e3;
  var TERMINAL_RESET_MS = 1600;
  var FETCH_BUFFER_CORRELATION_MS = 2500;
  var RECENT_FETCHES_CAP = 16;
  function looksLikeVideoIdSegment(segment) {
    if (segment.length < 10) {
      return false;
    }
    if (!/^[A-Za-z0-9_-]+$/.test(segment)) {
      return false;
    }
    let longestRun = 0;
    for (const run of segment.split(/[-_]+/)) {
      if (run.length > longestRun) {
        longestRun = run.length;
      }
    }
    return longestRun >= 10;
  }
  function urlIdHints(url) {
    const result = /* @__PURE__ */ new Set();
    let parsed;
    try {
      parsed = new URL(url);
    } catch {
      return result;
    }
    for (const segment of parsed.pathname.split("/")) {
      if (looksLikeVideoIdSegment(segment)) {
        result.add(segment);
      }
    }
    for (const key of VIDEO_ID_QUERY_KEYS) {
      const value = parsed.searchParams.get(key);
      if (value && value.length >= 4) {
        result.add(`${key}=${value}`);
      }
    }
    if (isInstagramCdnUrl(url)) {
      const assetId = instagramAssetId(url);
      if (assetId) {
        result.add(`xpv_asset_id=${assetId}`);
      }
    }
    return result;
  }
  function toFormKind(mimeTypes) {
    if (mimeTypes.size === 0) {
      return "unknown";
    }
    if (mimeTypes.size === 1) {
      const [mime] = mimeTypes;
      const codecsMatch = /codecs\s*=\s*"([^"]*)"|codecs\s*=\s*([^;]*)/i.exec(mime);
      const codecsText = codecsMatch?.[1] ?? codecsMatch?.[2] ?? "";
      const codecs = codecsText.split(",").map((part) => part.trim()).filter(Boolean);
      return codecs.length >= 2 ? "muxed" : "unknown";
    }
    let hasVideo = false;
    let hasAudio = false;
    for (const mime of mimeTypes) {
      if (mime.startsWith("video/")) {
        hasVideo = true;
      }
      if (mime.startsWith("audio/")) {
        hasAudio = true;
      }
    }
    return hasVideo && hasAudio ? "dash" : "unknown";
  }
  function trySelect(ctx, findUrlsByIdHint) {
    try {
      return selectMediaForPage(ctx, findUrlsByIdHint);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`${LOG_PREFIX} strategy for ${ctx.pageUrl.hostname} threw`, error);
      return { kind: "refused", message: chrome.i18n.getMessage("errorStrategyException", [message]) };
    }
  }
  function toSessionSnapshot(session) {
    const attributedUrls = Object.freeze(
      [...session.attributedUrls.entries()].map(([url, meta]) => Object.freeze({
        url,
        contentType: meta.contentType,
        capturedAt: meta.capturedAt
      }))
    );
    return Object.freeze({
      formKind: session.formKind,
      lastBoundAt: session.lastBoundAt,
      attributedUrls
    });
  }
  var MediaAttribution = class {
    elementsWithListeners = /* @__PURE__ */ new WeakSet();
    sessionsByElement = /* @__PURE__ */ new WeakMap();
    sessionsById = /* @__PURE__ */ new Map();
    sessionByMediaSourceId = /* @__PURE__ */ new Map();
    mediaSourceIdByObjectUrl = /* @__PURE__ */ new Map();
    selectionListenerByElement = /* @__PURE__ */ new WeakMap();
    ledger = new AttributionLedger();
    mutationObserver = null;
    performanceObserver = null;
    lastBoundSession = null;
    sessionCounter = 0;
    // The only way to definitively bind a URL to a specific <video>: lock the most recent
    // unlocked fetch to whichever session consumed it via appendBuffer.
    recentFetches = [];
    start() {
      document.querySelectorAll("video, audio").forEach((element) => {
        this.trackMediaElement(element);
      });
      this.mutationObserver = new MutationObserver(this.onMutations);
      this.mutationObserver.observe(document.documentElement, { childList: true, subtree: true });
      try {
        this.performanceObserver = new PerformanceObserver(this.onResourceTimingEntries);
        this.performanceObserver.observe({ type: "resource", buffered: true });
      } catch {
      }
      window.addEventListener("message", this.onMessage);
      console.log(`${LOG_PREFIX} attribution started in frame ${location.href}`);
    }
    onMutations = (mutations) => {
      for (const mutation of mutations) {
        mutation.addedNodes.forEach((node) => {
          if (node instanceof HTMLMediaElement) {
            this.trackMediaElement(node);
            return;
          }
          if (node instanceof Element) {
            node.querySelectorAll("video, audio").forEach((element) => {
              this.trackMediaElement(element);
            });
          }
        });
      }
    };
    trackMediaElement(element) {
      if (this.elementsWithListeners.has(element)) {
        return;
      }
      this.elementsWithListeners.add(element);
      element.addEventListener("loadstart", () => this.onMediaLoadStart(element));
      element.addEventListener("loadedmetadata", () => this.onMediaLoadedMetadata(element));
      element.addEventListener("durationchange", () => this.onMediaDurationChange(element));
      element.addEventListener("emptied", () => this.onMediaEmptied(element));
      const initialSrc = element.currentSrc || element.src || "";
      if (initialSrc) {
        this.openSessionFor(element);
      }
    }
    onMediaLoadStart(element) {
      const src = element.currentSrc || element.src || "";
      if (!src) {
        return;
      }
      const existing = this.sessionsByElement.get(element);
      if (!existing) {
        this.openSessionFor(element);
        return;
      }
      if (existing.src !== src) {
        console.log(`${LOG_PREFIX} ${existing.id} src changed \u2192 new session`, { from: existing.src, to: src });
        this.openSessionFor(element);
      }
    }
    onMediaLoadedMetadata(element) {
      let session = this.sessionsByElement.get(element);
      if (!session) {
        const src2 = element.currentSrc || element.src || "";
        if (!src2) {
          return;
        }
        session = this.openSessionFor(element);
      }
      this.transition(session, "armed", "loadedmetadata");
      const src = element.currentSrc || element.src || "";
      console.log(`${LOG_PREFIX} ${session.id} loadedmetadata`, { state: session.state, src });
      this.bindBlobToMediaSource(session, src);
      this.emitMediaMetadata(element, session);
    }
    onMediaDurationChange(element) {
      const session = this.sessionsByElement.get(element);
      if (!session) {
        return;
      }
      this.emitMediaMetadata(element, session);
    }
    emitMediaMetadata(element, session) {
      const urls = [...session.attributedUrls.keys()];
      if (element.currentSrc && !urls.includes(element.currentSrc)) {
        urls.push(element.currentSrc);
      }
      if (urls.length === 0) {
        return;
      }
      postMediaSignal({
        kind: "media_metadata",
        urls,
        duration: Number.isFinite(element.duration) ? element.duration : 0,
        videoWidth: element instanceof HTMLVideoElement ? element.videoWidth : 0,
        videoHeight: element instanceof HTMLVideoElement ? element.videoHeight : 0,
        posterUrl: element instanceof HTMLVideoElement ? element.poster || "" : ""
      });
    }
    onMediaEmptied(element) {
      const previous = this.sessionsByElement.get(element);
      if (!previous) {
        return;
      }
      console.log(`${LOG_PREFIX} ${previous.id} emptied \u2014 releasing`);
      this.notifyResolveListener(previous, "refused", chrome.i18n.getMessage("mediaReleased"));
      this.ledger.release(previous.id);
      this.sessionsByElement.delete(element);
      this.sessionsById.delete(previous.id);
      for (const mediaSourceId of previous.mediaSourceIds) {
        this.sessionByMediaSourceId.delete(mediaSourceId);
      }
      for (const [objectUrl, mediaSourceId] of this.mediaSourceIdByObjectUrl) {
        if (previous.mediaSourceIds.has(mediaSourceId)) {
          this.mediaSourceIdByObjectUrl.delete(objectUrl);
        }
      }
      if (this.lastBoundSession?.id === previous.id) {
        this.lastBoundSession = null;
      }
    }
    openSessionFor(element) {
      this.sessionCounter += 1;
      const src = element.currentSrc || element.src || "";
      const session = {
        id: `v-${this.sessionCounter}`,
        elementRef: new WeakRef(element),
        src,
        state: "inert",
        startedAt: performance.now(),
        lastBoundAt: 0,
        attributedUrls: /* @__PURE__ */ new Map(),
        mimeTypes: /* @__PURE__ */ new Set(),
        mediaSourceIds: /* @__PURE__ */ new Set(),
        idHints: /* @__PURE__ */ new Set(),
        formKind: "unknown"
      };
      this.sessionsByElement.set(element, session);
      this.sessionsById.set(session.id, session);
      console.log(`${LOG_PREFIX} ${session.id} opened`, { tag: element.tagName.toLowerCase(), src });
      if (src) {
        this.bindBlobToMediaSource(session, src);
        if (!src.startsWith("blob:")) {
          this.attribute(session, src, mimeFromUrl(src), 2, false);
        }
      }
      return session;
    }
    bindBlobToMediaSource(session, src) {
      if (!src.startsWith("blob:")) {
        return;
      }
      const mediaSourceId = this.mediaSourceIdByObjectUrl.get(src);
      if (!mediaSourceId) {
        return;
      }
      if (session.mediaSourceIds.has(mediaSourceId)) {
        return;
      }
      session.mediaSourceIds.add(mediaSourceId);
      this.sessionByMediaSourceId.set(mediaSourceId, session);
      this.lastBoundSession = session;
      session.lastBoundAt = performance.now();
      console.log(`${LOG_PREFIX} ${session.id} bound to ${mediaSourceId}`);
      const reclaimed = this.ledger.reclaimUrls(
        session.id,
        session.idHints,
        (url) => urlIdHints(url),
        performance.now()
      );
      if (reclaimed.urls.length > 0) {
        for (const url of reclaimed.urls) {
          this.handoffUrl(url, session);
        }
        console.log(`${LOG_PREFIX} ${session.id} reclaimed ${reclaimed.urls.length} url(s)`);
      }
      this.ledger.lockAllFor(session.id);
    }
    // capturedAt is reset so newSession's post-bind filter sees the URL as fresh.
    // trackMime, when present, beats the inherited container mime — Instagram's URLs have
    // no audio/video marker, so the SourceBuffer's `codecs=...` is the only way to know.
    handoffUrl(url, newSession, trackMime = "") {
      let oldSession = null;
      let inheritedContentType = "";
      for (const session of this.sessionsById.values()) {
        if (session.id === newSession.id) {
          continue;
        }
        const meta2 = session.attributedUrls.get(url);
        if (meta2) {
          oldSession = session;
          inheritedContentType = meta2.contentType;
          break;
        }
      }
      const meta = {
        contentType: trackMime || inheritedContentType,
        capturedAt: performance.now(),
        tier: "mse",
        lockedByMse: true
      };
      if (oldSession) {
        oldSession.attributedUrls.delete(url);
        const recomputed = /* @__PURE__ */ new Set();
        for (const [remainingUrl, remainingMeta] of oldSession.attributedUrls) {
          if (!remainingMeta.lockedByMse) {
            continue;
          }
          for (const d of urlIdHints(remainingUrl)) {
            recomputed.add(d);
          }
        }
        oldSession.idHints = recomputed;
      }
      newSession.attributedUrls.set(url, meta);
      for (const d of urlIdHints(url)) {
        newSession.idHints.add(d);
      }
      this.notifyResolveListener(newSession, newSession.state, "url-handoff");
      if (newSession.state === "inert" || newSession.state === "armed" || newSession.state === "waiting") {
        this.transition(newSession, "ready", `attributed ${url}`);
      }
    }
    // Media-only — analytics fetches landing right before appendBuffer would otherwise
    // get spuriously locked to the active session.
    recordFetch(url, contentType) {
      if (!this.isMediaUrl(url, contentType)) {
        return;
      }
      this.recentFetches.push({ url, capturedAt: performance.now() });
      if (this.recentFetches.length > RECENT_FETCHES_CAP) {
        this.recentFetches.shift();
      }
    }
    // Whichever session's MSE consumed the bytes is the URL's true owner — the network
    // mime alone can't distinguish DASH audio from DASH video when they share a container.
    attributeBufferAppend(mediaSourceId, sourceBufferMime) {
      const session = this.sessionByMediaSourceId.get(mediaSourceId);
      if (!session) {
        return;
      }
      const now = performance.now();
      for (let i = this.recentFetches.length - 1; i >= 0; i -= 1) {
        const entry = this.recentFetches[i];
        if (now - entry.capturedAt > FETCH_BUFFER_CORRELATION_MS) {
          break;
        }
        const ledgerEntry = this.ledger.lookup(entry.url);
        if (ledgerEntry?.lockedByMse) {
          const owner = this.sessionsById.get(ledgerEntry.sessionId);
          const meta = owner?.attributedUrls.get(entry.url);
          if (meta) {
            this.upgradeTrackMime(meta, sourceBufferMime);
          }
          continue;
        }
        const claim = this.ledger.claim(entry.url, session.id, "mse", now, true);
        if (claim.moved || claim.ownerId === session.id) {
          if (!session.attributedUrls.has(entry.url)) {
            this.handoffUrl(entry.url, session, sourceBufferMime);
          } else {
            const meta = session.attributedUrls.get(entry.url);
            if (meta) {
              this.upgradeTrackMime(meta, sourceBufferMime);
            }
            for (const d of urlIdHints(entry.url)) {
              session.idHints.add(d);
            }
          }
          console.log(`${LOG_PREFIX} ${session.id} attributed buffer-append \u2192 ${entry.url} via ${sourceBufferMime}`);
        }
        this.recentFetches.splice(i, 1);
        return;
      }
    }
    // SourceBuffer mime (with `codecs=...`) is always more specific than the container mime
    // it would overwrite, so once it's in place we leave it.
    upgradeTrackMime(meta, sourceBufferMime) {
      if (!sourceBufferMime) {
        return;
      }
      if (meta.contentType.includes("codecs")) {
        return;
      }
      meta.contentType = sourceBufferMime;
    }
    onMessage = (event) => {
      if (isMediaSignal(event.data)) {
        this.onSignal(event.data);
      }
    };
    onSignal(signal) {
      switch (signal.kind) {
        case "mse_objecturl": {
          this.mediaSourceIdByObjectUrl.set(signal.objectUrl, signal.mediaSourceId);
          for (const session of this.sessionsById.values()) {
            if (session.src === signal.objectUrl) {
              this.bindBlobToMediaSource(session, signal.objectUrl);
            }
          }
          return;
        }
        case "mse_source_buffer_added": {
          const session = this.sessionByMediaSourceId.get(signal.mediaSourceId);
          if (!session) {
            return;
          }
          if (session.mimeTypes.has(signal.mimeType)) {
            return;
          }
          session.mimeTypes.add(signal.mimeType);
          console.log(`${LOG_PREFIX} ${session.id} mime += ${signal.mimeType}`);
          const formKind = toFormKind(session.mimeTypes);
          if (formKind !== session.formKind) {
            session.formKind = formKind;
            console.log(`${LOG_PREFIX} ${session.id} formKind = ${formKind}`);
            this.notifyResolveListener(session, session.state, "formKind-changed");
          }
          return;
        }
        case "mse_buffer_appended":
          this.attributeBufferAppend(signal.mediaSourceId, signal.mimeType);
          return;
        case "request_completed":
          this.recordFetch(signal.url, signal.contentType);
          this.attributeFetch(signal.url, signal.contentType);
          return;
      }
    }
    onResourceTimingEntries = (list) => {
      for (const entry of list.getEntries()) {
        this.attributeFetch(entry.name, "");
      }
    };
    attributeFetch(url, contentType) {
      if (!this.isMediaUrl(url, contentType)) {
        return;
      }
      const existingEntry = this.ledger.lookup(url);
      if (existingEntry?.lockedByMse) {
        const owner = this.sessionsById.get(existingEntry.sessionId);
        if (owner && !owner.attributedUrls.has(url)) {
          this.recordAttribution(owner, url, contentType, "mse", true);
        }
        return;
      }
      const { session, tier } = this.pickSessionAndTier(url);
      if (!session) {
        console.log(`${LOG_PREFIX} orphan resource`, { url, contentType });
        return;
      }
      if (session.attributedUrls.has(url)) {
        return;
      }
      this.attribute(session, url, contentType, tier, false);
    }
    pickSessionAndTier(url) {
      const incoming = urlIdHints(url);
      if (incoming.size > 0) {
        for (const session of this.sessionsById.values()) {
          for (const d of incoming) {
            if (session.idHints.has(d)) {
              return { session, tier: 1 };
            }
          }
        }
      }
      if (this.lastBoundSession && this.sessionsById.has(this.lastBoundSession.id)) {
        return { session: this.lastBoundSession, tier: 2 };
      }
      if (this.sessionsById.size === 1) {
        for (const session of this.sessionsById.values()) {
          return { session, tier: 3 };
        }
      }
      return { session: null, tier: 3 };
    }
    attribute(session, url, contentType, tier, locked) {
      const claim = this.ledger.claim(url, session.id, tier, performance.now(), locked);
      const ownerSession = claim.ownerId === session.id ? session : this.sessionsById.get(claim.ownerId);
      if (!ownerSession) {
        return;
      }
      if (ownerSession.attributedUrls.has(url)) {
        return;
      }
      this.recordAttribution(ownerSession, url, contentType, tier, locked || claim.ownerId !== session.id);
    }
    recordAttribution(session, url, contentType, tier, locked) {
      session.attributedUrls.set(url, {
        contentType,
        capturedAt: performance.now(),
        tier,
        lockedByMse: locked
      });
      if (locked || tier === 0 || tier === 1 || tier === "mse") {
        for (const d of urlIdHints(url)) {
          session.idHints.add(d);
        }
      }
      if (session.state === "inert" || session.state === "armed" || session.state === "waiting") {
        this.transition(session, "ready", `attributed ${url}`);
      } else {
        this.notifyResolveListener(session, session.state, `attributed ${url}`);
      }
      console.log(`${LOG_PREFIX} ${session.id} += ${url}`, { hint: contentType, count: session.attributedUrls.size, tier, locked, state: session.state });
    }
    isMediaUrl(url, contentType) {
      if (!/^https?:/i.test(url)) {
        return false;
      }
      const extension = fileExtension(filenameFromUrl(url));
      return isCatCatchMedia(extension, contentType);
    }
    transition(session, next, reason) {
      const changed = session.state !== next;
      if (changed) {
        const previous = session.state;
        session.state = next;
        console.log(`${LOG_PREFIX} ${session.id} state ${previous} \u2192 ${next}`, { reason });
      }
      this.notifyResolveListener(session, next, reason);
      if (changed && (next === "dispatched" || next === "failed" || next === "refused")) {
        setTimeout(() => {
          if (session.state === next) {
            this.transition(session, session.attributedUrls.size > 0 ? "ready" : "armed", "terminal-reset");
          }
        }, TERMINAL_RESET_MS);
      }
    }
    notifyResolveListener(session, state, reason) {
      const element = session.elementRef.deref();
      if (!element) {
        return;
      }
      const listener = this.selectionListenerByElement.get(element);
      if (!listener) {
        return;
      }
      try {
        listener(state, reason);
      } catch {
      }
    }
    attributedUrlsFor(element) {
      if (!element) {
        return [];
      }
      const session = this.sessionsByElement.get(element);
      return session ? [...session.attributedUrls.keys()] : [];
    }
    async selectMediaForElement(element, hints, onStateChange) {
      if (!element) {
        return { kind: "refused", message: chrome.i18n.getMessage("errorMediaSourceUnrecognized") };
      }
      const session = this.sessionsByElement.get(element);
      if (!session) {
        return { kind: "refused", message: chrome.i18n.getMessage("errorMediaSourceUnrecognized") };
      }
      const pageUrl = new URL(location.href);
      const findUrlsByIdHint = (idHint) => this.lookupByIdHint(idHint);
      const buildCtx = () => ({
        clicked: toSessionSnapshot(session),
        pageUrl,
        hints
      });
      const initial = trySelect(buildCtx(), findUrlsByIdHint);
      if (initial.kind !== "pending") {
        this.applyResolutionToState(session, initial);
        return initial;
      }
      this.transition(session, "waiting", initial.reason);
      let lastPendingReason = initial.reason;
      return new Promise((resolve) => {
        let settled = false;
        const finish = (result) => {
          if (settled) {
            return;
          }
          settled = true;
          this.selectionListenerByElement.delete(element);
          clearTimeout(timer);
          this.applyResolutionToState(session, result);
          resolve(result);
        };
        this.selectionListenerByElement.set(element, (state, reason) => {
          onStateChange?.(state, reason);
          if (state === "refused" || state === "failed") {
            finish({ kind: "refused", message: reason });
            return;
          }
          const next = trySelect(buildCtx(), findUrlsByIdHint);
          if (next.kind === "pending") {
            lastPendingReason = next.reason;
            return;
          }
          finish(next);
        });
        const timer = setTimeout(() => {
          finish({ kind: "refused", message: chrome.i18n.getMessage("waitedTimeout", [lastPendingReason, String(Math.round(WAIT_FOR_TIMEOUT_MS / 1e3))]) });
        }, WAIT_FOR_TIMEOUT_MS);
      });
    }
    // Douyin uses this to reach across sessions for a prefetched URL claimed by a sibling
    // before the new <video> existed.
    lookupByIdHint(idHint) {
      const matches = [];
      for (const session of this.sessionsById.values()) {
        for (const [url, meta] of session.attributedUrls) {
          if (urlIdHints(url).has(idHint)) {
            matches.push({
              url,
              contentType: meta.contentType,
              capturedAt: meta.capturedAt
            });
          }
        }
      }
      return matches;
    }
    applyResolutionToState(session, resolution) {
      if (resolution.kind === "selection") {
        this.transition(session, "resolving", "selection-dispatch");
        return;
      }
      if (resolution.kind === "refused") {
        this.transition(session, "refused", resolution.message);
      }
    }
    markDispatchResult(element, ok, message) {
      if (!element) {
        return;
      }
      const session = this.sessionsByElement.get(element);
      if (!session) {
        return;
      }
      this.transition(session, ok ? "dispatched" : "failed", message);
    }
  };
  var attributionInstance = null;
  function startMediaAttribution() {
    if (attributionInstance) {
      return;
    }
    attributionInstance = new MediaAttribution();
    attributionInstance.start();
    window.__gdPageMedia = {
      attributedUrlsForElement: (element) => attributionInstance?.attributedUrlsFor(element) ?? [],
      selectMediaForElement: (element, hints, onStateChange) => attributionInstance?.selectMediaForElement(element, hints, onStateChange) ?? Promise.resolve({ kind: "refused", message: "attribution not ready" }),
      markDispatchResult: (element, ok, message) => attributionInstance?.markDispatchResult(element, ok, message)
    };
  }

  // src/content-script.ts
  installCatCatchBridge();
  startMediaAttribution();
  window.addEventListener("message", (event) => {
    const data = event.data;
    if (!data || data[MEDIA_SIGNAL_KEY] !== true || data.kind !== "media_metadata") {
      return;
    }
    chrome.runtime.sendMessage({
      type: "media_metadata",
      urls: data.urls,
      duration: data.duration,
      videoWidth: data.videoWidth,
      videoHeight: data.videoHeight,
      posterUrl: data.posterUrl
    });
  });
  function sendPagePoster() {
    const ogImage = document.querySelector('meta[property="og:image"]')?.content?.trim();
    if (!ogImage) {
      return;
    }
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const canvas = document.createElement("canvas");
        const scale = Math.min(1, 160 / img.naturalWidth);
        canvas.width = Math.round(img.naturalWidth * scale);
        canvas.height = Math.round(img.naturalHeight * scale);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          return;
        }
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL("image/jpeg", 0.7);
        chrome.runtime.sendMessage({ type: "page_poster", posterUrl: dataUrl });
      } catch {
      }
    };
    img.src = ogImage;
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", sendPagePoster);
  } else {
    sendPagePoster();
  }
  var bypassModifier = "alt";
  chrome.storage.local.get({ bypassModifier: "alt" }, (result) => {
    bypassModifier = result.bypassModifier || "alt";
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "local" && changes.bypassModifier) {
      bypassModifier = changes.bypassModifier.newValue || "alt";
    }
  });
  document.addEventListener("click", (event) => {
    const isHeld = bypassModifier === "alt" ? event.altKey : bypassModifier === "ctrl" ? event.ctrlKey : event.shiftKey;
    if (isHeld) {
      chrome.runtime.sendMessage({ type: "bypass_next_download" });
    }
  }, true);
})();
